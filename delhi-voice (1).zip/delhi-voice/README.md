# Delhi Voice

**The City. The Culture. The Stories.** A digital magazine and discovery platform for Delhi's heritage, culture, events, food and people.

**Stack:** React (Vite) · FastAPI · PostgreSQL · JWT auth · Alembic migrations · Docker

## Features

**Public site**
- Home, Heritage & Places (area/category filters), Culture, People, Food, Photo Stories, Events (upcoming/past, free/paid, cancelled/postponed badges), About, Contact
- Full-site search (stories, places, events)
- Reader accounts: sign up, save/bookmark stories and places
- Contributor Corner: submit story ideas, photo stories or local discoveries; track review status
- Newsletter signup (stored with consent; admin can view subscribers)
- Responsive, keyboard-friendly, skip link, alt text and photo credits, per-page titles/descriptions, sitemap + robots
- Privacy Policy and Terms (templates, see "Before going live")

**Admin panel** (`/admin`, roles enforced by the API)
- Dashboard; CRUD for articles, places, events, categories
- Image upload (JPEG/PNG/WebP, content-verified, 5 MB) and photo galleries with captions, alt text, credits
- Submission review queue: approve (creates a **draft** article), request edits, reject, with notes to the contributor
- Inbox (contact messages, newsletter subscribers); user management (roles, deactivate)

**Production hardening**
- Refuses to start in production with a weak/default `SECRET_KEY`; seeding refuses weak admin passwords and creates no demo accounts
- Login/signup/contact/newsletter rate limiting; security headers (HSTS, nosniff, frame deny); API docs disabled in production
- Passwords hashed with bcrypt; public signup can only create `reader` accounts; deactivated users are locked out immediately
- Alembic migrations; health check endpoint; GZip; non-root Docker image
- 20 backend tests (auth, permissions, CRUD, workflows, uploads, validation); CI workflow

## Run locally

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.seed            # SQLite by default; creates sample data + demo logins
uvicorn app.main:app --reload # http://localhost:8000  (docs at /docs in dev)

# frontend (second terminal)
cd frontend && npm install && npm run dev   # http://localhost:5173
```

Dev logins (local only): `admin@delhivoice.local` and `editor@delhivoice.local`, password `ChangeMe123!`.
Tests: `cd backend && pytest`

## Deploy to production

### Option A: Render (API + database) and Vercel (frontend)

1. Push this repo to GitHub.
2. **Render:** New > Blueprint > pick the repo (uses `render.yaml`: PostgreSQL + API container). Set `CORS_ORIGINS` and `SITE_URL` to your frontend URL, plus `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD` (12+ chars). The container runs `alembic upgrade head` on every start.
3. In the Render shell run **once**: `python -m app.seed`
4. **Vercel:** import the repo, root directory `frontend`, framework Vite, env var `VITE_API_URL=https://<your-api>.onrender.com`. In `frontend/vercel.json` and `frontend/public/robots.txt` replace the `YOUR-API` / `YOUR-DOMAIN` placeholders.
5. Sign in at `/login`, then replace the sample content with real content.

### Option B: any VPS with Docker

```bash
cp .env.example .env          # set POSTGRES_PASSWORD, SECRET_KEY, ADMIN_PASSWORD, SITE_URL
docker compose up -d --build
docker compose exec api python -m app.seed
```

The site is served on port 8080 (nginx serves the frontend and proxies `/api` and `/uploads`). Put a TLS-terminating proxy (Caddy, Cloudflare, your host's load balancer) in front for HTTPS.

## Before going live (important)

1. **Replace sample content.** Events are seeded as *Sample* (`is_sample`) and labelled in the UI. Add verified listings, then delete the samples.
2. **Images need persistent storage.** Uploads go to `UPLOAD_DIR`. On Render's free tier there is no disk, so uploads vanish on redeploy: attach a disk, or paste image URLs, or move uploads to Cloudinary/S3 (the upload endpoint is the one place to change). Use only photos you own or have licensed.
3. **No email is sent yet.** Newsletter signups are collected but nothing mails them, and there is no password reset. Add an email provider (Resend, SES, Brevo) before promising either.
4. **Legal pages are templates.** Have them reviewed for your situation (Indian IT/data-protection rules apply if you collect user data).
5. **SEO:** this is a single-page app, so titles/descriptions are set client-side. Google handles that, but social-share cards (WhatsApp/Twitter previews) will not show per-article details without pre-rendering or an edge function.
6. **Scaling:** the rate limiter is in-process memory, so run one API instance, or switch it to Redis before scaling out.
7. Change the admin password after first login, never commit `.env`, back up the database (managed Postgres usually offers this), and add uptime monitoring on `/api/health`.

## Layout

```
backend/   FastAPI app (app/), Alembic (migrations/), tests, Dockerfile
frontend/  React app (src/), nginx.conf, Dockerfile, vercel.json
docker-compose.yml · render.yaml · .github/workflows/ci.yml
```
