import os
import tempfile

os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"
os.environ["ADMIN_PASSWORD"] = "TestPass123!"
os.environ["DISABLE_RATE_LIMIT"] = "1"

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app import seed


@pytest.fixture(scope="module")
def client():
    seed.run()
    with TestClient(app) as c:
        yield c


def token(client, email, pw="TestPass123!"):
    r = client.post("/api/auth/login", data={"username": email, "password": pw})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_public_lists(client):
    assert client.get("/api/articles").json()["total"] == 5  # draft excluded
    assert client.get("/api/places").json()["total"] == 6
    assert client.get("/api/events?when=upcoming").json()["total"] == 4
    assert client.get("/api/events?when=past").json()["total"] == 1


def test_draft_hidden(client):
    assert client.get("/api/articles/draft-delhis-stepwells").status_code == 404


def test_filters(client):
    assert client.get("/api/places?area=Old Delhi").json()["total"] == 2
    assert client.get("/api/events?free=true").json()["total"] == 2


def test_bad_login(client):
    r = client.post("/api/auth/login", data={"username": "admin@delhivoice.local", "password": "wrong"})
    assert r.status_code == 401


def test_admin_requires_auth(client):
    assert client.get("/api/admin/articles").status_code == 401
    assert client.post("/api/admin/places", json={"name": "x", "slug": "x"}).status_code == 401


def test_reader_forbidden(client):
    admin = token(client, "admin@delhivoice.local")
    client.post("/api/admin/users", headers=admin,
                json={"name": "R", "email": "reader@x.com", "password": "TestPass123!", "role": "reader"})
    reader = token(client, "reader@x.com")
    assert client.get("/api/admin/articles", headers=reader).status_code == 403
    assert client.get("/api/admin/users", headers=reader).status_code == 403


def test_editor_cannot_manage_users(client):
    editor = token(client, "editor@delhivoice.local")
    assert client.get("/api/admin/users", headers=editor).status_code == 403
    assert client.get("/api/admin/articles", headers=editor).status_code == 200


def test_article_crud(client):
    h = token(client, "editor@delhivoice.local")
    body = {"title": "T", "slug": "t-article", "status": "published", "section": "culture"}
    r = client.post("/api/admin/articles", json=body, headers=h)
    assert r.status_code == 201 and r.json()["published_at"]
    aid = r.json()["id"]
    assert client.post("/api/admin/articles", json=body, headers=h).status_code == 409  # duplicate slug
    assert client.put(f"/api/admin/articles/{aid}", json={**body, "title": "T2"}, headers=h).json()["title"] == "T2"
    assert client.get("/api/articles/t-article").status_code == 200
    assert client.delete(f"/api/admin/articles/{aid}", headers=h).status_code == 204
    assert client.get("/api/articles/t-article").status_code == 404


def test_validation(client):
    h = token(client, "admin@delhivoice.local")
    r = client.post("/api/admin/articles", json={"title": "Bad", "slug": "Bad Slug!"}, headers=h)
    assert r.status_code == 422


# ---------- Phase 2 / production features ----------
def test_signup_and_login(client):
    r = client.post("/api/auth/signup", json={"name": "Asha", "email": "asha@example.com", "password": "LongPassw0rd"})
    assert r.status_code == 201 and r.json()["role"] == "reader"
    assert client.post("/api/auth/signup", json={"name": "A", "email": "asha@example.com", "password": "LongPassw0rd"}).status_code == 409
    assert client.post("/api/auth/signup", json={"name": "A", "email": "b@example.com", "password": "short"}).status_code == 422
    assert token(client, "asha@example.com", "LongPassw0rd")


def test_signup_cannot_choose_role(client):
    r = client.post("/api/auth/signup", json={"name": "Eve", "email": "eve@example.com", "password": "LongPassw0rd", "role": "admin"})
    assert r.json()["role"] == "reader"


def test_bookmarks(client):
    h = token(client, "asha@example.com", "LongPassw0rd")
    art = client.get("/api/articles").json()["items"][0]
    assert client.post("/api/me/bookmarks", json={"content_type": "article", "content_id": art["id"]}, headers=h).status_code == 201
    client.post("/api/me/bookmarks", json={"content_type": "article", "content_id": art["id"]}, headers=h)  # idempotent
    assert len(client.get("/api/me/bookmarks", headers=h).json()) == 1
    assert client.delete(f"/api/me/bookmarks/article/{art['id']}", headers=h).status_code == 204
    assert client.get("/api/me/bookmarks", headers=h).json() == []
    assert client.get("/api/me/bookmarks").status_code == 401


def test_cannot_bookmark_draft(client):
    admin = token(client, "admin@delhivoice.local")
    draft = next(a for a in client.get("/api/admin/articles", headers=admin).json() if a["status"] == "draft")
    h = token(client, "asha@example.com", "LongPassw0rd")
    assert client.post("/api/me/bookmarks", json={"content_type": "article", "content_id": draft["id"]}, headers=h).status_code == 404


def test_submission_workflow(client):
    user = token(client, "asha@example.com", "LongPassw0rd")
    r = client.post("/api/submissions", headers=user, json={"title": "Hidden chai stall", "body": "A lovely tiny stall near the lane.", "kind": "discovery"})
    assert r.status_code == 201 and r.json()["status"] == "pending"
    sid = r.json()["id"]
    assert client.get("/api/admin/submissions", headers=user).status_code == 403
    assert client.post(f"/api/admin/submissions/{sid}/review", headers=user, json={"status": "approved"}).status_code == 403
    editor = token(client, "editor@delhivoice.local")
    before = len(client.get("/api/admin/articles", headers=editor).json())
    assert client.post(f"/api/admin/submissions/{sid}/review", headers=editor, json={"status": "approved", "reviewer_notes": "Nice"}).json()["status"] == "approved"
    arts = client.get("/api/admin/articles", headers=editor).json()
    assert len(arts) == before + 1 and arts[0]["status"] == "draft"  # approval makes a DRAFT, not a live post
    assert client.get("/api/me/submissions", headers=user).json()[0]["reviewer_notes"] == "Nice"


def test_newsletter_and_contact(client):
    assert client.post("/api/newsletter/subscribe", json={"email": "n@example.com"}).status_code == 202
    assert client.post("/api/newsletter/subscribe", json={"email": "n@example.com"}).status_code == 202  # no enumeration
    assert client.post("/api/newsletter/subscribe", json={"email": "not-an-email"}).status_code == 422
    editor = token(client, "editor@delhivoice.local")
    subs = client.get("/api/admin/subscribers", headers=editor).json()
    assert len(subs) == 1
    assert client.get("/api/admin/subscribers").status_code == 401
    assert client.post("/api/contact", json={"name": "A", "email": "a@example.com", "message": "Hello there"}).status_code == 201
    assert len(client.get("/api/admin/messages", headers=editor).json()) == 1


def test_search(client):
    r = client.get("/api/search?q=Humayun").json()
    assert r["places"] and r["articles"]
    assert client.get("/api/search?q=a").status_code == 422


def test_user_management(client):
    admin = token(client, "admin@delhivoice.local")
    users = client.get("/api/admin/users", headers=admin).json()
    me = next(u for u in users if u["email"] == "admin@delhivoice.local")
    assert client.put(f"/api/admin/users/{me['id']}", headers=admin, json={"role": "reader"}).status_code == 400
    asha = next(u for u in users if u["email"] == "asha@example.com")
    assert client.put(f"/api/admin/users/{asha['id']}", headers=admin, json={"role": "editor"}).json()["role"] == "editor"
    client.put(f"/api/admin/users/{asha['id']}", headers=admin, json={"is_active": False})
    r = client.post("/api/auth/login", data={"username": "asha@example.com", "password": "LongPassw0rd"})
    assert r.status_code == 401  # deactivated accounts cannot sign in


def test_upload_validation(client):
    editor = token(client, "editor@delhivoice.local")
    png = b"\x89PNG\r\n\x1a\n" + b"0" * 50
    ok = client.post("/api/admin/upload", headers=editor, files={"file": ("a.png", png, "image/png")})
    assert ok.status_code == 200 and ok.json()["url"].startswith("/uploads/")
    assert client.get(ok.json()["url"]).status_code == 200
    bad = client.post("/api/admin/upload", headers=editor, files={"file": ("a.png", b"<script>alert(1)</script>", "image/png")})
    assert bad.status_code == 415
    assert client.post("/api/admin/upload", headers=editor, files={"file": ("a.svg", b"<svg/>", "image/svg+xml")}).status_code == 415
    assert client.post("/api/admin/upload", files={"file": ("a.png", png, "image/png")}).status_code == 401


def test_gallery_and_sitemap(client):
    h = token(client, "editor@delhivoice.local")
    body = {"title": "Photos", "slug": "photo-essay", "status": "published", "section": "photo",
            "gallery": [{"url": "/uploads/x.png", "caption": "c", "alt": "a", "credit": "me"}]}
    assert client.post("/api/admin/articles", json=body, headers=h).status_code == 201
    assert client.get("/api/articles/photo-essay").json()["gallery"][0]["credit"] == "me"
    xml = client.get("/api/sitemap.xml").text
    assert "/heritage/red-fort" in xml and "draft-delhis-stepwells" not in xml


def test_security_headers(client):
    r = client.get("/api/health")
    assert r.headers["x-content-type-options"] == "nosniff" and r.headers["x-frame-options"] == "DENY"
