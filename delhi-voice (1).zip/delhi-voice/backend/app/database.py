import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

from . import config  # noqa: F401  (loads .env)

# PostgreSQL in production (set DATABASE_URL); SQLite for quick local start.
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./delhi_voice.db")
# Hosts hand out postgres:// or postgresql://. SQLAlchemy 2.1+ would pick the psycopg3 driver for
# these, but we ship psycopg2, so name the driver explicitly.
for prefix in ("postgres://", "postgresql://"):
    if DATABASE_URL.startswith(prefix):
        DATABASE_URL = "postgresql+psycopg2://" + DATABASE_URL[len(prefix):]
        break

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
