import os
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, Depends, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import models, schemas
from .auth import (hash_password, verify_password, create_token, current_user, staff, admin_only)
from .config import CORS_ORIGINS, IS_PROD, UPLOAD_DIR
from .database import Base, engine, get_db
from .extras import router as extras_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    # In production the schema is managed by Alembic (alembic upgrade head).
    if not IS_PROD:
        Base.metadata.create_all(bind=engine)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    yield


app = FastAPI(title="Delhi Voice API", version="2.0.0", lifespan=lifespan,
              docs_url=None if IS_PROD else "/docs", redoc_url=None, openapi_url=None if IS_PROD else "/openapi.json")

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=False,
                   allow_methods=["GET", "POST", "PUT", "DELETE"], allow_headers=["Authorization", "Content-Type"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if IS_PROD:
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return resp


# Simple in-memory limiter for login/signup/contact/newsletter. For multiple instances use Redis.
_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(key: str, limit: int, window: int):
    now_ = time.monotonic()
    q = _hits[key]
    while q and now_ - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(429, "Too many attempts. Please try again later.")
    q.append(now_)


@app.middleware("http")
async def throttle_sensitive(request: Request, call_next):
    limits = {"/api/auth/login": (10, 300), "/api/auth/signup": (5, 3600),
              "/api/contact": (5, 3600), "/api/newsletter/subscribe": (10, 3600)}
    rule = limits.get(request.url.path)
    if rule and request.method == "POST" and os.getenv("DISABLE_RATE_LIMIT") != "1":
        ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0].strip()
        try:
            rate_limit(f"{request.url.path}:{ip}", *rule)
        except HTTPException as e:
            return JSONResponse({"detail": e.detail}, status_code=e.status_code)
    return await call_next(request)


@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {"status": "ok"}


app.include_router(extras_router)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR, check_dir=False), name="uploads")


# ---------- auth ----------
@app.post("/api/auth/login", response_model=schemas.Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(models.User).where(models.User.email == form.username.lower()))
    if not user or not user.is_active or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": create_token(user)}


@app.get("/api/auth/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(current_user)):
    return user


@app.post("/api/admin/users", response_model=schemas.UserOut, status_code=201)
def create_user(data: schemas.UserCreate, db: Session = Depends(get_db), _=Depends(admin_only)):
    if data.role not in ("admin", "editor", "contributor", "reader"):
        raise HTTPException(422, "Invalid role")
    u = models.User(name=data.name, email=data.email.lower(), password_hash=hash_password(data.password), role=data.role)
    db.add(u)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Email already registered")
    db.refresh(u)
    return u


@app.get("/api/admin/users", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _=Depends(admin_only)):
    return db.scalars(select(models.User).order_by(models.User.id)).all()


# ---------- helpers ----------
def save(db: Session, obj):
    db.add(obj)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Slug already exists or a referenced item is invalid")
    db.refresh(obj)
    return obj


def get_or_404(db: Session, model, id: int):
    obj = db.get(model, id)
    if not obj:
        raise HTTPException(404, "Not found")
    return obj


def paginate(stmt, db: Session, page: int, size: int):
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    items = db.scalars(stmt.offset((page - 1) * size).limit(size)).all()
    return items, total


def now():
    return datetime.now(timezone.utc)


# ---------- categories ----------
@app.get("/api/categories", response_model=list[schemas.CategoryOut])
def categories(content_type: str | None = None, db: Session = Depends(get_db)):
    stmt = select(models.Category).order_by(models.Category.name)
    if content_type:
        stmt = stmt.where(models.Category.content_type == content_type)
    return db.scalars(stmt).all()


@app.get("/api/admin/categories", response_model=list[schemas.CategoryOut])
def admin_categories(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.Category).order_by(models.Category.content_type, models.Category.name)).all()


@app.post("/api/admin/categories", response_model=schemas.CategoryOut, status_code=201)
def create_category(data: schemas.CategoryIn, db: Session = Depends(get_db), _=Depends(staff)):
    return save(db, models.Category(**data.model_dump()))


@app.put("/api/admin/categories/{id}", response_model=schemas.CategoryOut)
def update_category(id: int, data: schemas.CategoryIn, db: Session = Depends(get_db), _=Depends(staff)):
    obj = get_or_404(db, models.Category, id)
    for k, v in data.model_dump().items():
        setattr(obj, k, v)
    return save(db, obj)


@app.delete("/api/admin/categories/{id}", status_code=204)
def delete_category(id: int, db: Session = Depends(get_db), _=Depends(staff)):
    db.delete(get_or_404(db, models.Category, id))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Category is in use")


# ---------- articles (public) ----------
@app.get("/api/articles")
def list_articles(q: str | None = None, section: str | None = None, category: str | None = None,
                  featured: bool | None = None, page: int = Query(1, ge=1), size: int = Query(12, ge=1, le=50),
                  db: Session = Depends(get_db)):
    stmt = select(models.Article).where(models.Article.status == "published")
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(models.Article.title.ilike(like), models.Article.summary.ilike(like)))
    if section:
        stmt = stmt.where(models.Article.section == section)
    if category:
        stmt = stmt.join(models.Category).where(models.Category.slug == category)
    if featured is not None:
        stmt = stmt.where(models.Article.featured == featured)
    stmt = stmt.order_by(models.Article.published_at.desc())
    items, total = paginate(stmt, db, page, size)
    return {"items": [schemas.ArticleOut.model_validate(i) for i in items], "total": total, "page": page, "size": size}


@app.get("/api/articles/{slug}", response_model=schemas.ArticleOut)
def article_detail(slug: str, db: Session = Depends(get_db)):
    a = db.scalar(select(models.Article).where(models.Article.slug == slug, models.Article.status == "published"))
    if not a:
        raise HTTPException(404, "Article not found")
    return a


# ---------- articles (admin) ----------
@app.get("/api/admin/articles", response_model=list[schemas.ArticleOut])
def admin_articles(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.Article).order_by(models.Article.id.desc())).all()


@app.post("/api/admin/articles", response_model=schemas.ArticleOut, status_code=201)
def create_article(data: schemas.ArticleIn, db: Session = Depends(get_db), user=Depends(staff)):
    obj = models.Article(**data.model_dump(), author_id=user.id)
    if obj.status == "published":
        obj.published_at = now()
    return save(db, obj)


@app.put("/api/admin/articles/{id}", response_model=schemas.ArticleOut)
def update_article(id: int, data: schemas.ArticleIn, db: Session = Depends(get_db), _=Depends(staff)):
    obj = get_or_404(db, models.Article, id)
    for k, v in data.model_dump().items():
        setattr(obj, k, v)
    if obj.status == "published" and not obj.published_at:
        obj.published_at = now()
    return save(db, obj)


@app.delete("/api/admin/articles/{id}", status_code=204)
def delete_article(id: int, db: Session = Depends(get_db), _=Depends(staff)):
    db.delete(get_or_404(db, models.Article, id))
    db.commit()


# ---------- places ----------
@app.get("/api/places")
def list_places(q: str | None = None, area: str | None = None, category: str | None = None,
                featured: bool | None = None, page: int = Query(1, ge=1), size: int = Query(12, ge=1, le=50),
                db: Session = Depends(get_db)):
    stmt = select(models.Place).where(models.Place.status == "published")
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(models.Place.name.ilike(like), models.Place.description.ilike(like)))
    if area:
        stmt = stmt.where(models.Place.area == area)
    if category:
        stmt = stmt.join(models.Category).where(models.Category.slug == category)
    if featured is not None:
        stmt = stmt.where(models.Place.featured == featured)
    stmt = stmt.order_by(models.Place.name)
    items, total = paginate(stmt, db, page, size)
    return {"items": [schemas.PlaceOut.model_validate(i) for i in items], "total": total, "page": page, "size": size}


@app.get("/api/places/areas", response_model=list[str])
def place_areas(db: Session = Depends(get_db)):
    rows = db.scalars(select(models.Place.area).where(models.Place.status == "published").distinct()).all()
    return sorted(r for r in rows if r)


@app.get("/api/places/{slug}", response_model=schemas.PlaceOut)
def place_detail(slug: str, db: Session = Depends(get_db)):
    p = db.scalar(select(models.Place).where(models.Place.slug == slug, models.Place.status == "published"))
    if not p:
        raise HTTPException(404, "Place not found")
    return p


@app.get("/api/admin/places", response_model=list[schemas.PlaceOut])
def admin_places(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.Place).order_by(models.Place.id.desc())).all()


@app.post("/api/admin/places", response_model=schemas.PlaceOut, status_code=201)
def create_place(data: schemas.PlaceIn, db: Session = Depends(get_db), _=Depends(staff)):
    return save(db, models.Place(**data.model_dump()))


@app.put("/api/admin/places/{id}", response_model=schemas.PlaceOut)
def update_place(id: int, data: schemas.PlaceIn, db: Session = Depends(get_db), _=Depends(staff)):
    obj = get_or_404(db, models.Place, id)
    for k, v in data.model_dump().items():
        setattr(obj, k, v)
    return save(db, obj)


@app.delete("/api/admin/places/{id}", status_code=204)
def delete_place(id: int, db: Session = Depends(get_db), _=Depends(staff)):
    db.delete(get_or_404(db, models.Place, id))
    db.commit()


# ---------- events ----------
@app.get("/api/events")
def list_events(when: str = Query("upcoming", pattern="^(upcoming|past|all)$"), q: str | None = None,
                neighbourhood: str | None = None, free: bool | None = None, category: str | None = None,
                featured: bool | None = None, page: int = Query(1, ge=1), size: int = Query(12, ge=1, le=50),
                db: Session = Depends(get_db)):
    stmt = select(models.Event).where(models.Event.status.in_(["published", "postponed", "cancelled"]))
    if when == "upcoming":
        stmt = stmt.where(models.Event.start_at >= now()).order_by(models.Event.start_at)
    elif when == "past":
        stmt = stmt.where(models.Event.start_at < now()).order_by(models.Event.start_at.desc())
    else:
        stmt = stmt.order_by(models.Event.start_at)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(models.Event.title.ilike(like), models.Event.description.ilike(like)))
    if neighbourhood:
        stmt = stmt.where(models.Event.neighbourhood == neighbourhood)
    if free is True:
        stmt = stmt.where(models.Event.entry_fee.ilike("free"))
    elif free is False:
        stmt = stmt.where(~models.Event.entry_fee.ilike("free"))
    if category:
        stmt = stmt.join(models.Category).where(models.Category.slug == category)
    if featured is not None:
        stmt = stmt.where(models.Event.featured == featured)
    items, total = paginate(stmt, db, page, size)
    return {"items": [schemas.EventOut.model_validate(i) for i in items], "total": total, "page": page, "size": size}


@app.get("/api/events/{slug}", response_model=schemas.EventOut)
def event_detail(slug: str, db: Session = Depends(get_db)):
    e = db.scalar(select(models.Event).where(models.Event.slug == slug,
                                             models.Event.status.in_(["published", "postponed", "cancelled"])))
    if not e:
        raise HTTPException(404, "Event not found")
    return e


@app.get("/api/admin/events", response_model=list[schemas.EventOut])
def admin_events(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.Event).order_by(models.Event.start_at.desc())).all()


@app.post("/api/admin/events", response_model=schemas.EventOut, status_code=201)
def create_event(data: schemas.EventIn, db: Session = Depends(get_db), _=Depends(staff)):
    return save(db, models.Event(**data.model_dump()))


@app.put("/api/admin/events/{id}", response_model=schemas.EventOut)
def update_event(id: int, data: schemas.EventIn, db: Session = Depends(get_db), _=Depends(staff)):
    obj = get_or_404(db, models.Event, id)
    for k, v in data.model_dump().items():
        setattr(obj, k, v)
    return save(db, obj)


@app.delete("/api/admin/events/{id}", status_code=204)
def delete_event(id: int, db: Session = Depends(get_db), _=Depends(staff)):
    db.delete(get_or_404(db, models.Event, id))
    db.commit()


# ---------- dashboard ----------
@app.get("/api/admin/stats")
def stats(db: Session = Depends(get_db), _=Depends(staff)):
    def count(model, *where):
        return db.scalar(select(func.count()).select_from(model).where(*where)) or 0

    return {
        "published_articles": count(models.Article, models.Article.status == "published"),
        "draft_articles": count(models.Article, models.Article.status == "draft"),
        "upcoming_events": count(models.Event, models.Event.status == "published", models.Event.start_at >= now()),
        "places": count(models.Place),
        "users": count(models.User),
    }
