from datetime import datetime
from pydantic import BaseModel, EmailStr, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(ORM):
    id: int
    name: str
    email: str
    role: str
    is_active: bool = True


class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    role: str = "reader"


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    slug: str = Field(min_length=1, max_length=120, pattern=r"^[a-z0-9-]+$")
    description: str = ""
    content_type: str = Field(default="article", pattern="^(article|place|event)$")


class CategoryOut(ORM, CategoryIn):
    id: int


class GalleryItem(BaseModel):
    url: str = Field(max_length=500)
    caption: str = Field(default="", max_length=500)
    alt: str = Field(default="", max_length=300)
    credit: str = Field(default="", max_length=200)


class ArticleIn(BaseModel):
    gallery: list[GalleryItem] = []
    title: str = Field(min_length=1, max_length=255)
    slug: str = Field(min_length=1, max_length=280, pattern=r"^[a-z0-9-]+$")
    summary: str = ""
    body: str = ""
    cover_image: str = ""
    section: str = Field(default="culture", pattern="^(heritage|culture|people|food|photo)$")
    status: str = Field(default="draft", pattern="^(draft|published|archived)$")
    featured: bool = False
    category_id: int | None = None


class ArticleOut(ORM, ArticleIn):
    id: int
    published_at: datetime | None = None
    category: CategoryOut | None = None
    author: UserOut | None = None


class PlaceIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    slug: str = Field(min_length=1, max_length=220, pattern=r"^[a-z0-9-]+$")
    description: str = ""
    area: str = ""
    address: str = ""
    cover_image: str = ""
    practical_notes: str = ""
    map_link: str = ""
    status: str = Field(default="published", pattern="^(draft|published|archived)$")
    featured: bool = False
    category_id: int | None = None


class PlaceOut(ORM, PlaceIn):
    id: int
    category: CategoryOut | None = None


class EventIn(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    slug: str = Field(min_length=1, max_length=280, pattern=r"^[a-z0-9-]+$")
    description: str = ""
    start_at: datetime
    end_at: datetime | None = None
    venue: str = ""
    neighbourhood: str = ""
    entry_fee: str = "Free"
    organiser: str = ""
    booking_url: str = ""
    cover_image: str = ""
    status: str = Field(default="draft", pattern="^(draft|published|postponed|cancelled|archived)$")
    is_sample: bool = False
    featured: bool = False
    category_id: int | None = None


class EventOut(ORM, EventIn):
    id: int
    category: CategoryOut | None = None


class SignupIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)


class BookmarkIn(BaseModel):
    content_type: str = Field(pattern="^(article|place)$")
    content_id: int


class SubmissionIn(BaseModel):
    kind: str = Field(default="story", pattern="^(story|photo|discovery)$")
    title: str = Field(min_length=3, max_length=255)
    body: str = Field(min_length=10, max_length=10000)
    media_links: str = Field(default="", max_length=2000)


class SubmissionOut(ORM):
    id: int
    kind: str
    title: str
    body: str
    media_links: str
    status: str
    reviewer_notes: str
    created_at: datetime
    user: UserOut | None = None


class ReviewIn(BaseModel):
    status: str = Field(pattern="^(approved|rejected|changes_requested)$")
    reviewer_notes: str = Field(default="", max_length=2000)


class NewsletterIn(BaseModel):
    email: EmailStr


class ContactIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    message: str = Field(min_length=5, max_length=5000)


class ContactOut(ORM):
    id: int
    name: str
    email: str
    message: str
    handled: bool
    created_at: datetime


class SubscriberOut(ORM):
    id: int
    email: str
    created_at: datetime
    unsubscribed_at: datetime | None = None


class UserUpdate(BaseModel):
    role: str | None = Field(default=None, pattern="^(admin|editor|contributor|reader)$")
    is_active: bool | None = None
