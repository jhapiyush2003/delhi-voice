"""Phase 2 features: accounts, bookmarks, submissions, newsletter, contact, search, uploads, sitemap."""
import os
import secrets
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import models, schemas
from .auth import admin_only, current_user, hash_password, staff
from .config import MAX_UPLOAD_BYTES, SITE_URL, UPLOAD_DIR
from .database import get_db

router = APIRouter(prefix="/api")


def now():
    return datetime.now(timezone.utc)


# ---------- signup ----------
@router.post("/auth/signup", response_model=schemas.UserOut, status_code=201)
def signup(data: schemas.SignupIn, db: Session = Depends(get_db)):
    # Public signup can only ever create "reader" accounts.
    user = models.User(name=data.name.strip(), email=data.email.lower(),
                       password_hash=hash_password(data.password), role="reader")
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "An account with this email already exists")
    db.refresh(user)
    return user


# ---------- bookmarks ----------
@router.get("/me/bookmarks")
def my_bookmarks(db: Session = Depends(get_db), user=Depends(current_user)):
    rows = db.scalars(select(models.Bookmark).where(models.Bookmark.user_id == user.id)
                      .order_by(models.Bookmark.created_at.desc())).all()
    out = []
    for b in rows:
        model = models.Article if b.content_type == "article" else models.Place
        obj = db.get(model, b.content_id)
        if obj and obj.status == "published":
            out.append({"content_type": b.content_type, "content_id": b.content_id, "slug": obj.slug,
                        "title": getattr(obj, "title", None) or obj.name,
                        "summary": getattr(obj, "summary", None) or getattr(obj, "area", ""),
                        "cover_image": obj.cover_image})
    return out


@router.post("/me/bookmarks", status_code=201)
def add_bookmark(data: schemas.BookmarkIn, db: Session = Depends(get_db), user=Depends(current_user)):
    model = models.Article if data.content_type == "article" else models.Place
    obj = db.get(model, data.content_id)
    if not obj or obj.status != "published":
        raise HTTPException(404, "Item not found")
    exists = db.scalar(select(models.Bookmark).where(
        models.Bookmark.user_id == user.id, models.Bookmark.content_type == data.content_type,
        models.Bookmark.content_id == data.content_id))
    if not exists:
        db.add(models.Bookmark(user_id=user.id, **data.model_dump()))
        db.commit()
    return {"saved": True}


@router.delete("/me/bookmarks/{content_type}/{content_id}", status_code=204)
def remove_bookmark(content_type: str, content_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    b = db.scalar(select(models.Bookmark).where(
        models.Bookmark.user_id == user.id, models.Bookmark.content_type == content_type,
        models.Bookmark.content_id == content_id))
    if b:
        db.delete(b)
        db.commit()


# ---------- contributor submissions ----------
@router.post("/submissions", response_model=schemas.SubmissionOut, status_code=201)
def submit(data: schemas.SubmissionIn, db: Session = Depends(get_db), user=Depends(current_user)):
    recent = db.scalars(select(models.Submission).where(
        models.Submission.user_id == user.id, models.Submission.status == "pending")).all()
    if len(recent) >= 5:
        raise HTTPException(429, "You have 5 submissions awaiting review. Please wait for them to be reviewed.")
    s = models.Submission(user_id=user.id, **data.model_dump())
    db.add(s)
    db.commit()
    db.refresh(s)
    return s


@router.get("/me/submissions", response_model=list[schemas.SubmissionOut])
def my_submissions(db: Session = Depends(get_db), user=Depends(current_user)):
    return db.scalars(select(models.Submission).where(models.Submission.user_id == user.id)
                      .order_by(models.Submission.id.desc())).all()


@router.get("/admin/submissions", response_model=list[schemas.SubmissionOut])
def admin_submissions(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.Submission).order_by(models.Submission.id.desc())).all()


@router.post("/admin/submissions/{id}/review", response_model=schemas.SubmissionOut)
def review_submission(id: int, data: schemas.ReviewIn, db: Session = Depends(get_db), reviewer=Depends(staff)):
    s = db.get(models.Submission, id)
    if not s:
        raise HTTPException(404, "Not found")
    s.status, s.reviewer_notes, s.reviewer_id = data.status, data.reviewer_notes, reviewer.id
    if data.status == "approved":
        # Approval creates a DRAFT article so an editor still controls publication.
        base = "".join(c if c.isalnum() else "-" for c in s.title.lower()).strip("-")[:60] or "submission"
        slug = f"{base}-{secrets.token_hex(3)}"
        section = "photo" if s.kind == "photo" else "culture"
        db.add(models.Article(title=s.title, slug=slug, summary=s.body[:200], body=s.body, section=section,
                              status="draft", author_id=s.user_id))
    db.commit()
    db.refresh(s)
    return s


# ---------- newsletter ----------
@router.post("/newsletter/subscribe", status_code=202)
def subscribe(data: schemas.NewsletterIn, db: Session = Depends(get_db)):
    email = data.email.lower()
    sub = db.scalar(select(models.NewsletterSubscriber).where(models.NewsletterSubscriber.email == email))
    if sub:
        sub.unsubscribed_at = None  # re-subscribe
    else:
        db.add(models.NewsletterSubscriber(email=email, token=secrets.token_urlsafe(32), consent=True))
    db.commit()
    # Same response whether or not the email already existed (no enumeration).
    return {"status": "subscribed"}


@router.post("/newsletter/unsubscribe")
def unsubscribe(token: str = Query(min_length=10), db: Session = Depends(get_db)):
    sub = db.scalar(select(models.NewsletterSubscriber).where(models.NewsletterSubscriber.token == token))
    if not sub:
        raise HTTPException(404, "Invalid unsubscribe link")
    sub.unsubscribed_at = now()
    db.commit()
    return {"status": "unsubscribed"}


@router.get("/admin/subscribers", response_model=list[schemas.SubscriberOut])
def subscribers(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.NewsletterSubscriber).order_by(models.NewsletterSubscriber.id.desc())).all()


# ---------- contact ----------
@router.post("/contact", status_code=201)
def contact(data: schemas.ContactIn, db: Session = Depends(get_db)):
    db.add(models.ContactMessage(name=data.name.strip(), email=data.email.lower(), message=data.message.strip()))
    db.commit()
    return {"status": "received"}


@router.get("/admin/messages", response_model=list[schemas.ContactOut])
def messages(db: Session = Depends(get_db), _=Depends(staff)):
    return db.scalars(select(models.ContactMessage).order_by(models.ContactMessage.id.desc())).all()


@router.post("/admin/messages/{id}/handled", response_model=schemas.ContactOut)
def mark_handled(id: int, db: Session = Depends(get_db), _=Depends(staff)):
    m = db.get(models.ContactMessage, id)
    if not m:
        raise HTTPException(404, "Not found")
    m.handled = True
    db.commit()
    return m


# ---------- user management (admin) ----------
@router.put("/admin/users/{id}", response_model=schemas.UserOut)
def update_user(id: int, data: schemas.UserUpdate, db: Session = Depends(get_db), me=Depends(admin_only)):
    u = db.get(models.User, id)
    if not u:
        raise HTTPException(404, "Not found")
    if u.id == me.id and (data.role not in (None, "admin") or data.is_active is False):
        raise HTTPException(400, "You cannot demote or deactivate your own account")
    if data.role is not None:
        u.role = data.role
    if data.is_active is not None:
        u.is_active = data.is_active
    db.commit()
    db.refresh(u)
    return u


# ---------- search ----------
@router.get("/search")
def search(q: str = Query(min_length=2, max_length=100), db: Session = Depends(get_db)):
    like = f"%{q}%"
    arts = db.scalars(select(models.Article).where(
        models.Article.status == "published",
        or_(models.Article.title.ilike(like), models.Article.summary.ilike(like), models.Article.body.ilike(like))
    ).limit(10)).all()
    places = db.scalars(select(models.Place).where(
        models.Place.status == "published",
        or_(models.Place.name.ilike(like), models.Place.description.ilike(like), models.Place.area.ilike(like))
    ).limit(10)).all()
    events = db.scalars(select(models.Event).where(
        models.Event.status.in_(["published", "postponed", "cancelled"]),
        or_(models.Event.title.ilike(like), models.Event.description.ilike(like), models.Event.venue.ilike(like))
    ).limit(10)).all()
    return {
        "query": q,
        "articles": [schemas.ArticleOut.model_validate(a) for a in arts],
        "places": [schemas.PlaceOut.model_validate(p) for p in places],
        "events": [schemas.EventOut.model_validate(e) for e in events],
    }


# ---------- uploads ----------
ALLOWED = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
MAGIC = {b"\xff\xd8\xff": "image/jpeg", b"\x89PNG": "image/png", b"RIFF": "image/webp"}


@router.post("/admin/upload")
async def upload(file: UploadFile = File(...), _=Depends(staff)):
    if file.content_type not in ALLOWED:
        raise HTTPException(415, "Only JPEG, PNG or WebP images are allowed")
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File too large (max {MAX_UPLOAD_BYTES // 1024 // 1024} MB)")
    # Verify the real content, not just the declared type.
    if not any(data.startswith(m) and ALLOWED.get(t) == ALLOWED[file.content_type] for m, t in MAGIC.items()):
        raise HTTPException(415, "File content does not match an allowed image type")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    name = f"{uuid.uuid4().hex}{ALLOWED[file.content_type]}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return {"url": f"/uploads/{name}"}


# ---------- SEO ----------
@router.get("/sitemap.xml", include_in_schema=False)
def sitemap(db: Session = Depends(get_db)):
    urls = ["/", "/heritage", "/stories", "/events", "/culture", "/people", "/food", "/photo-stories", "/about", "/contact"]
    urls += [f"/stories/{s}" for s in db.scalars(select(models.Article.slug).where(models.Article.status == "published"))]
    urls += [f"/heritage/{s}" for s in db.scalars(select(models.Place.slug).where(models.Place.status == "published"))]
    urls += [f"/events/{s}" for s in db.scalars(select(models.Event.slug).where(models.Event.status.in_(["published", "postponed"])))]
    body = "".join(f"<url><loc>{SITE_URL}{u}</loc></url>" for u in urls)
    xml = f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>'
    return Response(xml, media_type="application/xml")
