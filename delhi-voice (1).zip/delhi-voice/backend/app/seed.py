"""Seed Delhi Voice with sample content.

Usage:  python -m app.seed
Admin credentials come from ADMIN_EMAIL / ADMIN_PASSWORD (defaults are for local demo only).
Event listings are SAMPLE data (is_sample=True) and shown as such in the UI.
"""
import os
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .auth import hash_password
from .config import IS_PROD
from .database import Base, engine, SessionLocal
from . import models

ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@delhivoice.local")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "ChangeMe123!")


def run():
    if IS_PROD:
        # Never create a known-password account on a public site.
        if "ADMIN_PASSWORD" not in os.environ or len(ADMIN_PASSWORD) < 12 or ADMIN_PASSWORD == "ChangeMe123!":
            raise SystemExit("In production set ADMIN_EMAIL and a strong ADMIN_PASSWORD (12+ chars) before seeding.")
    else:
        Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    if db.scalar(select(models.User).limit(1)):
        print("Database already seeded - skipping.")
        return

    admin = models.User(name="Delhi Voice Admin", email=ADMIN_EMAIL, password_hash=hash_password(ADMIN_PASSWORD), role="admin")
    editor = models.User(name="Sample Editor", email="editor@delhivoice.local", password_hash=hash_password(ADMIN_PASSWORD), role="editor")
    db.add(admin)
    if not IS_PROD:  # demo editor account only for local development
        db.add(editor)
    db.flush()

    cats = {
        slug: models.Category(name=name, slug=slug, content_type=ct, description=desc)
        for slug, name, ct, desc in [
            ("monuments", "Monuments", "place", "Forts, tombs and landmarks"),
            ("markets", "Markets", "place", "Bazaars and street-side culture"),
            ("museums", "Museums & Galleries", "place", "Spaces for art and history"),
            ("gardens", "Gardens & Parks", "place", "Green Delhi"),
            ("history", "History", "article", "Stories from the past"),
            ("arts", "Arts & Performance", "article", "Music, theatre, literature"),
            ("food-stories", "Food Stories", "article", "What Delhi eats"),
            ("festivals", "Festivals", "event", "Celebrations"),
            ("walks", "Heritage Walks", "event", "Guided routes"),
            ("exhibitions", "Exhibitions", "event", "Galleries and shows"),
        ]
    }
    db.add_all(cats.values())
    db.flush()

    places = [
        ("Red Fort (Lal Qila)", "red-fort", "Old Delhi", "monuments", True,
         "The Mughal fortress-palace built by Shah Jahan, completed in the mid-17th century, and a UNESCO World Heritage Site. Its red sandstone walls front the old walled city of Shahjahanabad.",
         "Closed on Mondays. Go early in the day for softer light and thinner crowds. Check current ticketing before you go."),
        ("Humayun's Tomb", "humayuns-tomb", "Nizamuddin", "monuments", True,
         "An early Mughal garden-tomb set in a charbagh layout, widely seen as a forerunner of the Taj Mahal. The surrounding Nizamuddin area has layers of Sufi and Mughal history.",
         "Combine with a walk through Nizamuddin Basti. Carry water; there is little shade on the main axis."),
        ("Chandni Chowk", "chandni-chowk", "Old Delhi", "markets", True,
         "The old city's main artery, lined with lanes for spices, silver, paper, attar and food. Best explored on foot or by rickshaw.",
         "Mornings are calmer. Many shops close on Sundays; keep valuables secure in crowds."),
        ("Lodhi Garden", "lodhi-garden", "Lodhi Road", "gardens", False,
         "A landscaped park dotted with 15th and 16th century tombs of the Sayyid and Lodi dynasties. A favourite for morning walks.",
         "Open from dawn; quietest on weekday mornings."),
        ("National Museum", "national-museum", "Central Delhi", "museums", False,
         "One of India's largest museums, holding collections that span prehistory to modern art.",
         "Plan at least two to three hours. Confirm timings and closure days on the official website."),
        ("Dilli Haat INA", "dilli-haat-ina", "INA", "markets", False,
         "An open-air craft bazaar with state-wise stalls and a food court, popular for handloom and handicrafts.",
         "Entry is ticketed. Weekdays are less crowded."),
    ]
    for name, slug, area, cat, feat, desc, notes in places:
        db.add(models.Place(name=name, slug=slug, area=area, category_id=cats[cat].id, featured=feat,
                            description=desc, practical_notes=notes, status="published",
                            map_link="https://www.google.com/maps/search/" + name.replace(" ", "+") + "+Delhi"))

    now = datetime.now(timezone.utc)
    arts = [
        ("Walking Shahjahanabad: A Morning in Old Delhi", "walking-shahjahanabad", "heritage", "history", True,
         "How the walled city was planned, and how to read its lanes today.",
         "Shahjahanabad was laid out in the 17th century as the Mughal capital, with Chandni Chowk as its grand avenue running from the Red Fort.\n\nToday its lanes (galis) hold havelis, mosques, temples and markets side by side. Start at the Fort, walk the main avenue, then slip into the side lanes where trades still cluster by street: paper, spices, jewellery, books.\n\nTake your time, wear comfortable shoes, and stop for a cup of chai along the way."),
        ("Why Humayun's Tomb Matters", "why-humayuns-tomb-matters", "heritage", "history", True,
         "The garden-tomb that shaped Mughal architecture in India.",
         "Humayun's Tomb introduced the monumental garden-tomb to the subcontinent. Its symmetrical gardens, double dome and red sandstone with white marble inlay became touchstones for later Mughal buildings.\n\nA long conservation effort in the 2000s restored the complex and the neighbouring gardens, and it remains one of the most rewarding places to spend an afternoon."),
        ("Delhi's Street Food Trail, One Lane at a Time", "street-food-trail", "food", "food-stories", True,
         "A beginner's guide to eating your way through the old city.",
         "Old Delhi's food culture is best approached slowly. Share plates, try one speciality per stop, and ask locals for what is freshly made.\n\nDetails such as prices, timings and which stalls are open change often, so check recent reviews before planning a trip."),
        ("The Quiet Craft of the Bookbinders", "quiet-craft-bookbinders", "people", "arts", False,
         "A sample profile on artisans keeping old trades alive.",
         "This is a sample feature used to demonstrate the People of Delhi layout: a short introduction, a Q&A with the artisan, and a gallery of portraits.\n\nReplace this text with a real interview and credited photographs."),
        ("Where Delhi Goes to Hear Music", "where-delhi-hears-music", "culture", "arts", False,
         "From qawwali evenings to indie gigs, a map of live music in the city.",
         "Delhi's live music scene stretches from devotional qawwali at Sufi shrines to small-venue gigs across the city.\n\nThis is a sample article. An editor can update it from the admin panel."),
    ]
    for i, (title, slug, section, cat, feat, summary, body) in enumerate(arts):
        db.add(models.Article(title=title, slug=slug, section=section, category_id=cats[cat].id, featured=feat,
                              summary=summary, body=body, status="published", author_id=(admin if IS_PROD else editor).id,
                              published_at=now - timedelta(days=i * 3)))
    db.add(models.Article(title="Draft: Delhi's Stepwells", slug="draft-delhis-stepwells", section="heritage",
                          category_id=cats["history"].id, summary="Work in progress.", body="Draft body.",
                          status="draft", author_id=(admin if IS_PROD else editor).id))

    events = [
        ("Sample: Old Delhi Heritage Walk", "sample-old-delhi-heritage-walk", "walks", "Old Delhi", "Meet at Red Fort entrance", "Rs 500", 7),
        ("Sample: Winter Craft Festival", "sample-winter-craft-festival", "festivals", "INA", "Dilli Haat INA", "Rs 30", 14),
        ("Sample: Contemporary Art Showcase", "sample-art-showcase", "exhibitions", "Central Delhi", "City Gallery", "Free", 21),
        ("Sample: Evening of Qawwali", "sample-evening-of-qawwali", "festivals", "Nizamuddin", "Community courtyard", "Free", 28),
        ("Sample: Past Heritage Photo Walk", "sample-past-photo-walk", "walks", "Mehrauli", "Mehrauli Archaeological Park", "Free", -20),
    ]
    for title, slug, cat, hood, venue, fee, days in events:
        start = now + timedelta(days=days, hours=2)
        db.add(models.Event(title=title, slug=slug, category_id=cats[cat].id, neighbourhood=hood, venue=venue,
                            entry_fee=fee, start_at=start, end_at=start + timedelta(hours=3), status="published",
                            organiser="Delhi Voice (sample)", is_sample=True, featured=days in (7, 14),
                            description="Sample listing for demonstration. Not a verified real-world event; always confirm details with the organiser."))
    db.commit()
    print(f"Seeded. Admin login: {ADMIN_EMAIL}" + ("" if IS_PROD else f" / {ADMIN_PASSWORD}"))


if __name__ == "__main__":
    run()
