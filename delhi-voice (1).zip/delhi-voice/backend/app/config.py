import os

from dotenv import load_dotenv

load_dotenv()

ENV = os.getenv("ENV", "development")  # development | production
IS_PROD = ENV == "production"

SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-me")
if IS_PROD and (SECRET_KEY == "dev-only-change-me" or len(SECRET_KEY) < 32):
    raise RuntimeError("In production, SECRET_KEY must be set to a random string of at least 32 characters.")

CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]
SITE_URL = os.getenv("SITE_URL", "http://localhost:5173").rstrip("/")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./uploads")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "5")) * 1024 * 1024
TOKEN_MINUTES = int(os.getenv("TOKEN_MINUTES", "480"))
