import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api";

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [saved, setSaved] = useState([]); // [{content_type, content_id, ...}]

  const loadSaved = useCallback(() => api("/me/bookmarks").then(setSaved).catch(() => setSaved([])), []);

  useEffect(() => {
    if (!getToken()) return;
    api("/auth/me")
      .then((u) => { setUser(u); loadSaved(); })
      .catch(() => setToken(null))
      .finally(() => setLoading(false));
  }, [loadSaved]);

  const login = async (email, password) => {
    const { access_token } = await api("/auth/login", { method: "POST", form: { username: email, password } });
    setToken(access_token);
    const me = await api("/auth/me");
    setUser(me);
    loadSaved();
    return me;
  };
  const signup = async (name, email, password) => {
    await api("/auth/signup", { method: "POST", body: { name, email, password } });
    return login(email, password);
  };
  const logout = () => { setToken(null); setUser(null); setSaved([]); };

  const isSaved = (type, id) => saved.some((b) => b.content_type === type && b.content_id === id);
  const toggleSave = async (type, id) => {
    if (isSaved(type, id)) await api(`/me/bookmarks/${type}/${id}`, { method: "DELETE" });
    else await api("/me/bookmarks", { method: "POST", body: { content_type: type, content_id: id } });
    await loadSaved();
  };

  return <AuthCtx.Provider value={{ user, loading, login, signup, logout, saved, isSaved, toggleSave }}>{children}</AuthCtx.Provider>;
}
