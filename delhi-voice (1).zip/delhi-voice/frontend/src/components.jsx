import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { api, media } from "./api";
import { useAuth } from "./auth";

const links = [
  ["/", "Home"],
  ["/heritage", "Heritage"],
  ["/culture", "Culture"],
  ["/events", "Events"],
  ["/people", "People"],
  ["/food", "Food"],
  ["/photo-stories", "Photo Stories"],
  ["/about", "About"],
];

/** Per-page <title> and meta description (client-side SEO; see README for pre-rendering notes). */
export function usePageMeta(title, description) {
  useEffect(() => {
    document.title = title ? `${title} | Delhi Voice` : "Delhi Voice: The City. The Culture. The Stories.";
    const el = document.querySelector('meta[name="description"]');
    if (el && description) el.setAttribute("content", description.slice(0, 160));
  }, [title, description]);
}

export function Layout() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const search = (e) => {
    e.preventDefault();
    if (q.trim().length >= 2) { nav(`/search?q=${encodeURIComponent(q.trim())}`); setOpen(false); }
  };
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <header className="site-header">
        <div className="container nav">
          <Link to="/" className="logo" onClick={() => setOpen(false)}>
            Delhi Voice<small>The City. The Culture. The Stories.</small>
          </Link>
          <button className="menu-btn" aria-expanded={open} aria-label="Toggle menu" onClick={() => setOpen(!open)}>☰</button>
          <nav className={`nav-links ${open ? "open" : ""}`} aria-label="Main">
            {links.map(([to, label]) => (
              <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)} className={({ isActive }) => (isActive ? "active" : "")}>{label}</NavLink>
            ))}
            <form onSubmit={search} role="search" className="nav-search">
              <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" aria-label="Search site" />
            </form>
            {user ? (
              <>
                <NavLink to="/saved" onClick={() => setOpen(false)}>Saved</NavLink>
                {["admin", "editor"].includes(user.role) && <NavLink to="/admin" onClick={() => setOpen(false)}>Admin</NavLink>}
                <button className="linklike" onClick={() => { logout(); setOpen(false); nav("/"); }}>Sign out</button>
              </>
            ) : (
              <NavLink to="/login" onClick={() => setOpen(false)}>Sign in</NavLink>
            )}
          </nav>
        </div>
      </header>
      <main id="main"><Outlet /></main>
      <footer className="footer">
        <div className="container footer-grid">
          <div>
            <div className="logo" style={{ color: "#fff" }}>Delhi Voice</div>
            <p>A digital magazine for Delhi's heritage, culture, events, food and people.</p>
            <Newsletter />
          </div>
          <div><b>Explore</b><br /><Link to="/heritage">Heritage</Link><br /><Link to="/stories">All stories</Link><br /><Link to="/events">Events</Link><br /><Link to="/contribute">Contribute</Link></div>
          <div><b>Delhi Voice</b><br /><Link to="/about">About</Link><br /><Link to="/contact">Contact</Link><br /><Link to="/privacy">Privacy</Link><br /><Link to="/terms">Terms</Link></div>
        </div>
      </footer>
    </>
  );
}

function Newsletter() {
  const [state, setState] = useState({ status: "idle", msg: "" });
  const submit = async (e) => {
    e.preventDefault();
    const email = new FormData(e.target).get("email");
    setState({ status: "busy", msg: "" });
    try {
      await api("/newsletter/subscribe", { method: "POST", body: { email } });
      setState({ status: "done", msg: "Thanks for subscribing!" });
    } catch (ex) { setState({ status: "error", msg: ex.message }); }
  };
  if (state.status === "done") return <p className="meta" style={{ color: "#f3c98b" }} role="status">{state.msg}</p>;
  return (
    <form className="newsletter" onSubmit={submit}>
      <input type="email" name="email" required placeholder="Your email" aria-label="Email for newsletter" />
      <button className="btn small" disabled={state.status === "busy"}>Subscribe</button>
      {state.status === "error" && <span role="alert" className="meta" style={{ color: "#f6b3ad", width: "100%" }}>{state.msg}</span>}
      <span className="meta" style={{ width: "100%" }}>By subscribing you agree to our <Link to="/privacy">privacy policy</Link>. Unsubscribe any time.</span>
    </form>
  );
}

const palette = ["#7b2435", "#a0402f", "#8a5a1e", "#4d5a3a", "#3f4a6b", "#6b3f5e"];
export function Cover({ src, label, seed = 0, alt }) {
  if (src) return <div className="ph" style={{ backgroundImage: `url(${media(src)})` }} role="img" aria-label={alt || label} />;
  const i = [...(label || "")].reduce((a, c) => a + c.charCodeAt(0), seed) % palette.length;
  return (
    <div className="ph" aria-hidden="true" style={{ background: `linear-gradient(135deg, ${palette[i]}, ${palette[(i + 2) % palette.length]})` }}>
      {(label || "").split(/[\s:(]+/).slice(0, 3).join(" ")}
    </div>
  );
}

export function useFetch(fn, deps) {
  const [state, set] = useState({ loading: true, data: null, error: null });
  useEffect(() => {
    let live = true;
    set((s) => ({ ...s, loading: true, error: null }));
    fn().then((data) => live && set({ loading: false, data, error: null }))
        .catch((error) => live && set({ loading: false, data: null, error }));
    return () => { live = false; };
    // eslint-disable-next-line
  }, deps);
  return state;
}

export function Status({ state, children, emptyMsg = "Nothing here yet." }) {
  if (state.loading) return <div className="loading" role="status">Loading…</div>;
  if (state.error) return <div className="error" role="alert">{state.error.message}</div>;
  if (Array.isArray(state.data?.items) && !state.data.items.length) return <div className="empty">{emptyMsg}</div>;
  return children;
}

export const fmtDate = (d, opts = { day: "numeric", month: "short", year: "numeric" }) =>
  d ? new Date(d).toLocaleDateString("en-IN", opts) : "";
export const fmtDateTime = (d) =>
  d ? new Date(d).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) : "";

export function Pager({ page, size, total, onChange }) {
  const pages = Math.max(1, Math.ceil(total / size));
  if (pages <= 1) return null;
  return (
    <div className="pager">
      <button className="btn secondary small" disabled={page <= 1} onClick={() => onChange(page - 1)}>← Prev</button>
      <span className="meta">Page {page} of {pages}</span>
      <button className="btn secondary small" disabled={page >= pages} onClick={() => onChange(page + 1)}>Next →</button>
    </div>
  );
}

export function SaveButton({ type, id }) {
  const { user, isSaved, toggleSave } = useAuth();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const saved = user && isSaved(type, id);
  const click = async () => {
    if (!user) return nav("/login", { state: { from: window.location.pathname } });
    setBusy(true);
    try { await toggleSave(type, id); } finally { setBusy(false); }
  };
  return <button className={`btn small ${saved ? "" : "secondary"}`} onClick={click} disabled={busy} aria-pressed={!!saved}>{saved ? "★ Saved" : "☆ Save"}</button>;
}
