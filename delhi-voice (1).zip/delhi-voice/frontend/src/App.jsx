import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Layout } from "./components";
import Home from "./pages/Home";
import { About, ArticleDetail, Articles, EventDetail, Events, Heritage, NotFound, PhotoStories, PlaceDetail } from "./pages/Public";
import { Contact, Contribute, Privacy, Saved, SearchPage, Signup, Terms, Unsubscribe } from "./pages/Account";
import { AdminArticles, AdminCategories, AdminEvents, AdminInbox, AdminPlaces, AdminSubmissions, AdminUsers, Dashboard, Login, RequireStaff } from "./pages/Admin";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="heritage" element={<Heritage />} />
          <Route path="heritage/:slug" element={<PlaceDetail />} />
          <Route path="stories" element={<Articles />} />
          <Route path="stories/:slug" element={<ArticleDetail />} />
          <Route path="culture" element={<Articles section="culture" />} />
          <Route path="people" element={<Articles section="people" />} />
          <Route path="food" element={<Articles section="food" />} />
          <Route path="photo-stories" element={<PhotoStories />} />
          <Route path="events" element={<Events />} />
          <Route path="events/:slug" element={<EventDetail />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="about" element={<About />} />
          <Route path="contact" element={<Contact />} />
          <Route path="contribute" element={<Contribute />} />
          <Route path="saved" element={<Saved />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="terms" element={<Terms />} />
          <Route path="unsubscribe" element={<Unsubscribe />} />
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
          <Route path="articles" element={<Navigate to="/stories" replace />} />
          <Route path="admin" element={<RequireStaff />}>
            <Route index element={<Dashboard />} />
            <Route path="articles" element={<AdminArticles />} />
            <Route path="places" element={<AdminPlaces />} />
            <Route path="events" element={<AdminEvents />} />
            <Route path="categories" element={<AdminCategories />} />
            <Route path="submissions" element={<AdminSubmissions />} />
            <Route path="inbox" element={<AdminInbox />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </>
  );
}
