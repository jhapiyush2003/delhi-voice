import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import { Cover, Status, fmtDate, useFetch, usePageMeta } from "../components";
import { ArticleCard, EventCard, PlaceCard } from "./Home";

export function Signup() {
  usePageMeta("Create account");
  const { signup, user } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/saved" replace />;
  const submit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    if (f.get("password") !== f.get("confirm")) return setErr("Passwords do not match");
    setBusy(true); setErr("");
    try { await signup(f.get("name"), f.get("email"), f.get("password")); nav(loc.state?.from || "/saved", { replace: true }); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  return (
    <div className="container login panel">
      <h1 style={{ fontSize: "1.8rem" }}>Create your account</h1>
      <p className="meta">Save stories and places, and send in your own discoveries.</p>
      <form onSubmit={submit}>
        <label>Name<input name="name" required maxLength={120} autoComplete="name" /></label>
        <label>Email<input name="email" type="email" required autoComplete="email" /></label>
        <label>Password (8+ characters)<input name="password" type="password" required minLength={8} maxLength={72} autoComplete="new-password" /></label>
        <label>Confirm password<input name="confirm" type="password" required minLength={8} autoComplete="new-password" /></label>
        {err && <div className="error" role="alert">{err}</div>}
        <button className="btn" disabled={busy}>{busy ? "Creating…" : "Create account"}</button>
        <span className="meta">By signing up you agree to the <Link to="/terms">Terms</Link> and <Link to="/privacy">Privacy Policy</Link>. Already registered? <Link to="/login">Sign in</Link></span>
      </form>
    </div>
  );
}

export function Saved() {
  usePageMeta("Saved");
  const { user, loading, saved, toggleSave } = useAuth();
  if (loading) return <div className="container loading">Loading…</div>;
  if (!user) return <Navigate to="/login" state={{ from: "/saved" }} replace />;
  return (
    <div className="container">
      <div className="page-head"><h1>Saved</h1><p className="meta">Stories and places you've bookmarked.</p></div>
      {!saved.length ? <div className="empty">Nothing saved yet. Tap “Save” on any story or place.</div> : (
        <div className="grid">
          {saved.map((b) => (
            <div key={`${b.content_type}-${b.content_id}`} className="card">
              <Link to={b.content_type === "article" ? `/stories/${b.slug}` : `/heritage/${b.slug}`}><Cover src={b.cover_image} label={b.title} /></Link>
              <div className="card-body">
                <span className="tag">{b.content_type === "article" ? "Story" : "Place"}</span>
                <h3><Link to={b.content_type === "article" ? `/stories/${b.slug}` : `/heritage/${b.slug}`}>{b.title}</Link></h3>
                <p>{b.summary}</p>
                <div><button className="btn secondary small" onClick={() => toggleSave(b.content_type, b.content_id)}>Remove</button></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function Contribute() {
  usePageMeta("Contribute", "Send Delhi Voice a story idea, photo or local discovery for review.");
  const { user, loading } = useAuth();
  const [version, setVersion] = useState(0);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState("");
  const mine = useFetch(() => (user ? api("/me/submissions") : Promise.resolve({ items: [] })), [user, version]);
  if (loading) return <div className="container loading">Loading…</div>;
  if (!user) return (
    <div className="container prose">
      <h1>Contributor Corner</h1>
      <p>Have a story idea, a photograph or a hidden gem to share? Everything is reviewed by our editors before anything is published.</p>
      <Link className="btn" to="/login" state={{ from: "/contribute" }}>Sign in</Link> <Link className="btn secondary" to="/signup" state={{ from: "/contribute" }}>Create account</Link>
    </div>
  );
  const submit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    setErr(""); setDone(false);
    try { await api("/submissions", { method: "POST", body: f }); setDone(true); e.target.reset(); setVersion((v) => v + 1); }
    catch (ex) { setErr(ex.message); }
  };
  const list = Array.isArray(mine.data) ? mine.data : [];
  return (
    <div className="container" style={{ maxWidth: 780 }}>
      <div className="page-head"><h1>Contributor Corner</h1><p className="meta">Send a story idea, photo link or local discovery. Editors review every submission; approval creates a draft, not an instant post.</p></div>
      <form className="form" onSubmit={submit}>
        <label>Type<select name="kind"><option value="story">Story idea</option><option value="photo">Photo story</option><option value="discovery">Local discovery</option></select></label>
        <label>Title<input name="title" required minLength={3} maxLength={255} /></label>
        <label className="full">Your pitch or text<textarea name="body" required minLength={10} maxLength={10000} /></label>
        <label className="full">Links to photos or sources (optional)<input name="media_links" maxLength={2000} placeholder="Only share work you own or have permission to share" /></label>
        {err && <div className="error full" role="alert">{err}</div>}
        {done && <div className="success full" role="status">Thanks! Your submission is awaiting review.</div>}
        <div className="full"><button className="btn">Submit for review</button></div>
      </form>
      {list.length > 0 && (
        <>
          <h2>Your submissions</h2>
          <div className="table-wrap"><table><thead><tr><th>Title</th><th>Status</th><th>Editor notes</th><th>Sent</th></tr></thead>
            <tbody>{list.map((s) => <tr key={s.id}><td>{s.title}</td><td><span className={`badge ${s.status === "approved" ? "ok" : s.status === "rejected" ? "bad" : "warn"}`}>{s.status.replace("_", " ")}</span></td><td>{s.reviewer_notes || "-"}</td><td>{fmtDate(s.created_at)}</td></tr>)}</tbody></table></div>
        </>
      )}
    </div>
  );
}

export function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  usePageMeta(q ? `Search: ${q}` : "Search");
  const s = useFetch(() => (q.length >= 2 ? api(`/search?q=${encodeURIComponent(q)}`) : Promise.resolve(null)), [q]);
  const d = s.data;
  const total = d ? d.articles.length + d.places.length + d.events.length : 0;
  return (
    <div className="container">
      <div className="page-head"><h1>Search</h1>{q && <p className="meta">Results for “{q}”</p>}</div>
      {q.length < 2 ? <div className="empty">Type at least two characters in the search box.</div> : (
        <Status state={s}>
          {d && !total && <div className="empty">No results for “{q}”. Try a different word.</div>}
          {d && d.places.length > 0 && <><h2>Places</h2><div className="grid">{d.places.map((p) => <PlaceCard key={p.id} p={p} />)}</div></>}
          {d && d.articles.length > 0 && <><h2 style={{ marginTop: 32 }}>Stories</h2><div className="grid">{d.articles.map((a) => <ArticleCard key={a.id} a={a} />)}</div></>}
          {d && d.events.length > 0 && <><h2 style={{ marginTop: 32 }}>Events</h2><div className="grid">{d.events.map((e) => <EventCard key={e.id} e={e} />)}</div></>}
        </Status>
      )}
    </div>
  );
}

export function Contact() {
  usePageMeta("Contact", "Get in touch with the Delhi Voice team.");
  const [state, setState] = useState({ status: "idle", msg: "" });
  const submit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    setState({ status: "busy", msg: "" });
    try { await api("/contact", { method: "POST", body }); setState({ status: "done", msg: "" }); e.target.reset(); }
    catch (ex) { setState({ status: "error", msg: ex.message }); }
  };
  return (
    <div className="container" style={{ maxWidth: 680 }}>
      <div className="page-head"><h1>Contact us</h1><p className="meta">Corrections, partnerships or questions: we read every message.</p></div>
      <form className="form" onSubmit={submit}>
        <label>Name<input name="name" required maxLength={120} /></label>
        <label>Email<input name="email" type="email" required /></label>
        <label className="full">Message<textarea name="message" required minLength={5} maxLength={5000} /></label>
        {state.status === "error" && <div className="error full" role="alert">{state.msg}</div>}
        {state.status === "done" && <div className="success full" role="status">Thanks, your message has been sent.</div>}
        <div className="full"><button className="btn" disabled={state.status === "busy"}>Send message</button></div>
      </form>
    </div>
  );
}

export function Unsubscribe() {
  usePageMeta("Unsubscribe");
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const [msg, setMsg] = useState("");
  const go = async () => {
    try { await api(`/newsletter/unsubscribe?token=${encodeURIComponent(token)}`, { method: "POST" }); setMsg("You have been unsubscribed."); }
    catch (ex) { setMsg(ex.message); }
  };
  return <div className="container prose"><h1>Unsubscribe</h1>{msg ? <p role="status">{msg}</p> : <button className="btn" onClick={go} disabled={!token}>Confirm unsubscribe</button>}</div>;
}

export function Privacy() {
  usePageMeta("Privacy Policy");
  return (
    <div className="container prose">
      <h1>Privacy Policy</h1>
      <p className="meta">Template for a demo project. Have a qualified person review it before running a public service.</p>
      <h2>What we collect</h2>
      <p>Account details you provide (name, email, a securely hashed password), the stories and places you save, submissions you send us, messages through the contact form, and your email if you subscribe to the newsletter.</p>
      <h2>How we use it</h2>
      <p>To run your account, review submissions, reply to messages and send the newsletter you asked for. We do not sell personal data.</p>
      <h2>Your choices</h2>
      <p>You can unsubscribe from the newsletter at any time. To have your account or data removed, use the <Link to="/contact">contact form</Link>.</p>
      <h2>Security</h2>
      <p>Passwords are stored as salted hashes, connections use HTTPS, and admin access is permission-controlled.</p>
    </div>
  );
}

export function Terms() {
  usePageMeta("Terms of Use");
  return (
    <div className="container prose">
      <h1>Terms of Use</h1>
      <p className="meta">Template for a demo project. Have a qualified person review it before running a public service.</p>
      <h2>Content</h2>
      <p>Delhi Voice content is provided for general information. Event, timing and price details can change; always confirm with the organiser or venue. Items labelled “Sample” are demonstration data, not verified listings.</p>
      <h2>Contributions</h2>
      <p>When you submit text or photos you confirm they are yours or you have permission to share them, and you allow Delhi Voice to publish them with credit if approved. We may edit or decline any submission.</p>
      <h2>Conduct</h2>
      <p>Do not misuse the site, attempt to access restricted areas, or submit unlawful, hateful or infringing material.</p>
    </div>
  );
}
