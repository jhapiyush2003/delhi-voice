import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, media, qs } from "../api";
import { Cover, Pager, SaveButton, Status, useFetch, usePageMeta, fmtDate, fmtDateTime } from "../components";
import { ArticleCard, EventCard, PlaceCard } from "./Home";

const SIZE = 9;

function Listing({ title, intro, path, filters, Card, extraParams = {} }) {
  const [f, setF] = useState({ q: "", ...Object.fromEntries(filters.map((x) => [x.key, ""])) });
  const [page, setPage] = useState(1);
  const state = useFetch(() => api(`${path}${qs({ ...f, ...extraParams, page, size: SIZE })}`), [JSON.stringify(f), page, JSON.stringify(extraParams)]);
  const set = (k, v) => { setF({ ...f, [k]: v }); setPage(1); };
  return (
    <div className="container">
      <div className="page-head">
        <h1>{title}</h1>
        <p className="meta" style={{ maxWidth: "60ch" }}>{intro}</p>
      </div>
      <div className="filters" role="search">
        <input type="search" placeholder="Search…" aria-label="Search" value={f.q} onChange={(e) => set("q", e.target.value)} />
        {filters.map((x) => (
          <select key={x.key} aria-label={x.label} value={f[x.key]} onChange={(e) => set(x.key, e.target.value)}>
            <option value="">{x.label}</option>
            {x.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        ))}
      </div>
      <Status state={state} emptyMsg="No results match your filters. Try clearing the search.">
        <p className="meta">{state.data?.total} result{state.data?.total === 1 ? "" : "s"}</p>
        <div className="grid">{state.data?.items?.map((it) => <Card key={it.id} item={it} />)}</div>
        {state.data && <Pager page={page} size={SIZE} total={state.data.total} onChange={setPage} />}
      </Status>
    </div>
  );
}

const useCats = (type) => {
  const s = useFetch(() => api(`/categories?content_type=${type}`), [type]);
  return (s.data || []).map((c) => ({ value: c.slug, label: c.name }));
};

export function Heritage() {
  usePageMeta("Heritage & Places", "Monuments, markets, gardens and museums across Delhi.");
  const cats = useCats("place");
  const areas = useFetch(() => api("/places/areas"), []);
  return (
    <Listing
      title="Heritage & Places"
      intro="Monuments, markets, gardens and museums across Delhi. Filter by area or type."
      path="/places"
      filters={[
        { key: "area", label: "All areas", options: (areas.data || []).map((a) => ({ value: a, label: a })) },
        { key: "category", label: "All types", options: cats },
      ]}
      Card={({ item }) => <PlaceCard p={item} />}
    />
  );
}

const SECTIONS = {
  all: { title: "Stories", intro: "Features, interviews, guides and photo essays from across the city." },
  culture: { title: "Culture & Lifestyle", intro: "Art, music, theatre, markets, traditions and the creative life of Delhi." },
  people: { title: "People of Delhi", intro: "Interviews and profiles of artists, artisans, creators and changemakers." },
  food: { title: "Food & Cafés", intro: "Street-food guides, historic eateries and neighbourhood food trails. Details such as prices and timings change, so check before you go." },
  heritage: { title: "Heritage & History", intro: "Stories of monuments, old neighbourhoods and the city's past." },
};

export function Articles({ section = "all" }) {
  const cfg = SECTIONS[section];
  usePageMeta(cfg.title, cfg.intro);
  const cats = useCats("article");
  const sections = [["heritage", "Heritage"], ["culture", "Culture"], ["people", "People"], ["food", "Food"], ["photo", "Photo stories"]];
  const filters = [{ key: "category", label: "All categories", options: cats }];
  if (section === "all") filters.unshift({ key: "section", label: "All sections", options: sections.map(([value, label]) => ({ value, label })) });
  return (
    <Listing key={section} title={cfg.title} intro={cfg.intro} path="/articles"
      extraParams={section === "all" ? {} : { section }} filters={filters}
      Card={({ item }) => <ArticleCard a={item} />} />
  );
}

export function PhotoStories() {
  usePageMeta("Photo Stories", "Photo essays about Delhi's streets, monuments, markets and everyday life.");
  const [page, setPage] = useState(1);
  const s = useFetch(() => api(`/articles${qs({ section: "photo", page, size: 9 })}`), [page]);
  return (
    <div className="container">
      <div className="page-head"><h1>Photo Stories</h1><p className="meta" style={{ maxWidth: "60ch" }}>Photo essays about streets, monuments, markets, festivals and everyday life.</p></div>
      <Status state={s} emptyMsg="No photo stories published yet.">
        <div className="photo-grid">{s.data?.items?.map((a) => <ArticleCard key={a.id} a={{ ...a, cover_image: a.cover_image || a.gallery?.[0]?.url }} />)}</div>
        {s.data && <Pager page={page} size={9} total={s.data.total} onChange={setPage} />}
      </Status>
    </div>
  );
}

export function Events() {
  usePageMeta("Events", "Festivals, exhibitions, heritage walks and performances in Delhi.");
  const [when, setWhen] = useState("upcoming");
  const cats = useCats("event");
  return (
    <>
      <div className="container" style={{ paddingTop: 24 }}>
        <div className="actions">
          {["upcoming", "past"].map((w) => (
            <button key={w} className={`btn small ${when === w ? "" : "secondary"}`} onClick={() => setWhen(w)}>
              {w === "upcoming" ? "Upcoming" : "Past events"}
            </button>
          ))}
        </div>
      </div>
      <Listing
        key={when}
        title={when === "upcoming" ? "What's On" : "Past Events"}
        intro="Festivals, exhibitions, walks and performances. Always confirm details with the organiser before you go."
        path="/events"
        extraParams={{ when }}
        filters={[
          { key: "free", label: "Free & paid", options: [{ value: "true", label: "Free entry" }, { value: "false", label: "Paid entry" }] },
          { key: "category", label: "All categories", options: cats },
        ]}
        Card={({ item }) => <EventCard e={item} />}
      />
    </>
  );
}

export function PlaceDetail() {
  const { slug } = useParams();
  const s = useFetch(() => api(`/places/${slug}`), [slug]);
  const p = s.data;
  usePageMeta(p?.name, p?.description);
  return (
    <div className="container" style={{ paddingTop: 32 }}>
      <Link to="/heritage">← All places</Link>
      <Status state={s}>
        {p && (
          <>
            <div className="page-head"><span className="tag">{p.category?.name}</span><h1>{p.name}</h1><p className="meta">{p.area}{p.address ? ` · ${p.address}` : ""}</p><SaveButton type="place" id={p.id} /></div>
            <div className="detail-grid">
              <div><Cover src={p.cover_image} label={p.name} /><div className="article" style={{ margin: "20px 0" }}><p>{p.description}</p></div></div>
              <aside className="panel">
                <h3>Visiting tips</h3>
                <p>{p.practical_notes || "No notes yet."}</p>
                {p.map_link && <a className="btn small" href={p.map_link} target="_blank" rel="noreferrer">Open in Maps</a>}
                <p className="meta">Timings and ticketing change; check official sources before visiting.</p>
              </aside>
            </div>
          </>
        )}
      </Status>
    </div>
  );
}

export function ArticleDetail() {
  const { slug } = useParams();
  const s = useFetch(() => api(`/articles/${slug}`), [slug]);
  const a = s.data;
  usePageMeta(a?.title, a?.summary);
  return (
    <div className="container" style={{ paddingTop: 32 }}>
      <Link to="/stories">← All stories</Link>
      <Status state={s}>
        {a && (
          <>
            <div className="page-head" style={{ maxWidth: "70ch", margin: "0 auto" }}>
              <span className="tag">{a.category?.name || a.section}</span>
              <h1>{a.title}</h1>
              <p className="meta">{a.author?.name ? `By ${a.author.name} · ` : ""}{fmtDate(a.published_at)}</p>
              <SaveButton type="article" id={a.id} />
            </div>
            <div style={{ maxWidth: 900, margin: "0 auto 24px" }}><Cover src={a.cover_image} label={a.title} /></div>
            <article className="article">
              <p style={{ fontSize: "1.2rem", color: "var(--muted)" }}>{a.summary}</p>
              {a.body.split(/\n\n+/).map((para, i) => <p key={i}>{para}</p>)}
            </article>
            {a.gallery?.length > 0 && (
              <div className="gallery" style={{ maxWidth: 1000, margin: "28px auto" }}>
                {a.gallery.map((g, i) => (
                  <figure key={i}>
                    <img src={media(g.url)} alt={g.alt || g.caption || ""} loading="lazy" />
                    {(g.caption || g.credit) && <figcaption>{g.caption}{g.credit && <><br /><small>Photo: {g.credit}</small></>}</figcaption>}
                  </figure>
                ))}
              </div>
            )}
          </>
        )}
      </Status>
    </div>
  );
}

export function EventDetail() {
  const { slug } = useParams();
  const s = useFetch(() => api(`/events/${slug}`), [slug]);
  const e = s.data;
  usePageMeta(e?.title, e?.description);
  return (
    <div className="container" style={{ paddingTop: 32 }}>
      <Link to="/events">← All events</Link>
      <Status state={s}>
        {e && (
          <>
            <div className="page-head">
              <span className="tag">{e.category?.name}</span><h1>{e.title}</h1>
              {e.status === "cancelled" && <span className="badge bad">Cancelled</span>}
              {e.status === "postponed" && <span className="badge warn">Postponed</span>}
              {new Date(e.start_at) < new Date() && <span className="badge">Past event</span>}
            </div>
            {e.is_sample && <div className="notice">Sample listing for demonstration. This is not a verified real-world event.</div>}
            <div className="detail-grid">
              <div><Cover src={e.cover_image} label={e.title} seed={3} /><div className="article" style={{ margin: "20px 0" }}><p>{e.description}</p></div></div>
              <aside className="panel">
                <h3>Details</h3>
                <p><b>When:</b> {fmtDateTime(e.start_at)}{e.end_at ? ` – ${fmtDateTime(e.end_at)}` : ""}</p>
                <p><b>Where:</b> {e.venue}{e.neighbourhood ? `, ${e.neighbourhood}` : ""}</p>
                <p><b>Entry:</b> {e.entry_fee}</p>
                {e.organiser && <p><b>Organiser:</b> {e.organiser}</p>}
                {e.booking_url && <a className="btn small" href={e.booking_url} target="_blank" rel="noreferrer">Book / more info</a>}
              </aside>
            </div>
          </>
        )}
      </Status>
    </div>
  );
}

export function About() {
  usePageMeta("About", "Delhi Voice is a digital magazine and discovery platform for Delhi.");
  return (
    <div className="container article" style={{ paddingTop: 48 }}>
      <h1>About Delhi Voice</h1>
      <p>Delhi Voice is a digital magazine and discovery platform for the city's heritage, culture, events, food and people. It aims to feel like a thoughtful city magazine: strong stories first, practical guidance second.</p>
      <p>Delhi Voice is built with React, FastAPI and PostgreSQL. Items marked “Sample” are demonstration content, not verified listings. Want to contribute? Visit the <Link to="/contribute">Contributor Corner</Link>.</p>
    </div>
  );
}

export function NotFound() {
  return <div className="container empty" style={{ marginTop: 48 }}><h2>Page not found</h2><Link to="/">Back to home</Link></div>;
}
