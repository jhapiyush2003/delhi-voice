import { useState } from "react";
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import { api, media, upload } from "../api";
import { useAuth } from "../auth";
import { Status, useFetch, usePageMeta, fmtDate, fmtDateTime } from "../components";

export function Login() {
  const { login, user } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  usePageMeta("Sign in");
  if (user) return <Navigate to={["admin", "editor"].includes(user.role) ? "/admin" : "/saved"} replace />;
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    const fd = new FormData(e.target);
    try {
      const me = await login(fd.get("email"), fd.get("password"));
      nav(loc.state?.from || (["admin", "editor"].includes(me.role) ? "/admin" : "/saved"), { replace: true });
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  return (
    <div className="container login panel">
      <h1 style={{ fontSize: "1.8rem" }}>Sign in</h1>
      <form onSubmit={submit}>
        <label>Email<input name="email" type="email" required autoComplete="username" /></label>
        <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
        {err && <div className="error" role="alert">{err}</div>}
        <button className="btn" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
        <span className="meta">New here? <Link to="/signup" state={loc.state}>Create an account</Link></span>
      </form>
    </div>
  );
}

export function RequireStaff() {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="container loading">Loading…</div>;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  if (!["admin", "editor"].includes(user.role)) return <div className="container error" style={{ marginTop: 40 }}>Your account does not have access to the admin panel.</div>;
  return (
    <div className="container admin">
      <nav className="side" aria-label="Admin">
        {[["/admin", "Dashboard"], ["/admin/articles", "Articles"], ["/admin/places", "Places"], ["/admin/events", "Events"], ["/admin/categories", "Categories"], ["/admin/submissions", "Submissions"], ["/admin/inbox", "Inbox"], ...(user.role === "admin" ? [["/admin/users", "Users"]] : [])].map(([to, l]) => (
          <NavLink key={to} to={to} end={to === "/admin"} className={({ isActive }) => (isActive ? "active" : "")}>{l}</NavLink>
        ))}
        <hr style={{ width: "100%", border: 0, borderTop: "1px solid var(--line)" }} />
        <span className="meta" style={{ padding: "4px 12px" }}>{user.name} ({user.role})</span>
        <LogoutBtn />
      </nav>
      <div><Outlet /></div>
    </div>
  );
}

function LogoutBtn() {
  const { logout } = useAuth();
  return <button className="btn secondary small" onClick={logout}>Sign out</button>;
}

export function Dashboard() {
  const s = useFetch(() => api("/admin/stats"), []);
  const labels = { published_articles: "Published articles", draft_articles: "Draft articles", upcoming_events: "Upcoming events", places: "Places", users: "Users" };
  return (
    <>
      <h1 style={{ fontSize: "1.8rem" }}>Dashboard</h1>
      <Status state={s}>
        <div className="stats">{s.data && Object.entries(s.data).map(([k, v]) => <div className="stat" key={k}><b>{v}</b>{labels[k]}</div>)}</div>
        <div className="actions">
          <Link className="btn small" to="/admin/articles">New article</Link>
          <Link className="btn small" to="/admin/events">Add event</Link>
          <Link className="btn small" to="/admin/places">Add place</Link>
        </div>
      </Status>
    </>
  );
}

const slugify = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const toLocalInput = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

/** Config-driven CRUD screen used for articles, places, events and categories. */
function Manager({ title, resource, titleKey, fields, columns, catType, defaults }) {
  const [version, setVersion] = useState(0);
  const [editing, setEditing] = useState(null); // null | {} (new) | item
  const [error, setError] = useState("");
  const list = useFetch(() => api(`/admin/${resource}`), [resource, version]);
  const cats = useFetch(() => (catType ? api(`/categories?content_type=${catType}`) : Promise.resolve([])), [catType, version]);

  const startEdit = (item) => {
    const form = { ...defaults, ...(item || {}) };
    fields.forEach((f) => { if (f.type === "datetime") form[f.key] = toLocalInput(form[f.key]); });
    setEditing({ id: item?.id, form });
    setError("");
  };

  const save = async (e) => {
    e.preventDefault();
    const body = { ...editing.form };
    if (!body.slug) body.slug = slugify(body[titleKey] || "");
    fields.forEach((f) => {
      if (f.type === "datetime") body[f.key] = body[f.key] ? new Date(body[f.key]).toISOString() : null;
      if (f.type === "category") body[f.key] = body[f.key] ? Number(body[f.key]) : null;
    });
    try {
      await api(`/admin/${resource}${editing.id ? `/${editing.id}` : ""}`, { method: editing.id ? "PUT" : "POST", body });
      setEditing(null); setVersion((v) => v + 1);
    } catch (ex) { setError(ex.message); }
  };

  const remove = async (item) => {
    if (!window.confirm(`Delete "${item[titleKey]}"? This cannot be undone.`)) return;
    try { await api(`/admin/${resource}/${item.id}`, { method: "DELETE" }); setVersion((v) => v + 1); }
    catch (ex) { alert(ex.message); }
  };

  const set = (k, v) => setEditing((s) => ({ ...s, form: { ...s.form, [k]: v } }));

  return (
    <>
      <div className="section-head"><h1 style={{ fontSize: "1.8rem", margin: 0 }}>{title}</h1>
        {!editing && <button className="btn small" onClick={() => startEdit(null)}>+ New</button>}</div>

      {editing && (
        <form className="form" onSubmit={save}>
          <h3 className="full" style={{ margin: 0 }}>{editing.id ? "Edit" : "New"} {title.toLowerCase().replace(/s$/, "")}</h3>
          {fields.map((f) => {
            const v = editing.form[f.key] ?? "";
            const cls = f.full ? "full" : "";
            if (f.type === "image") return <ImageField key={f.key} label={f.label} value={v} onChange={(x) => set(f.key, x)} />;
            if (f.type === "gallery") return <GalleryField key={f.key} value={editing.form[f.key] || []} onChange={(x) => set(f.key, x)} />;
            if (f.type === "bool")
              return <label key={f.key} className={`check ${cls}`}><input type="checkbox" checked={!!editing.form[f.key]} onChange={(e) => set(f.key, e.target.checked)} />{f.label}</label>;
            return (
              <label key={f.key} className={cls}>{f.label}
                {f.type === "textarea" ? <textarea value={v} required={f.required} onChange={(e) => set(f.key, e.target.value)} />
                  : f.type === "select" ? <select value={v} onChange={(e) => set(f.key, e.target.value)}>{f.options.map((o) => <option key={o} value={o}>{o}</option>)}</select>
                  : f.type === "category" ? <select value={v ?? ""} onChange={(e) => set(f.key, e.target.value)}><option value="">None</option>{(cats.data || []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
                  : <input type={f.type === "datetime" ? "datetime-local" : "text"} value={v} required={f.required} onChange={(e) => set(f.key, e.target.value)} placeholder={f.key === "slug" ? "auto from title if empty" : ""} />}
              </label>
            );
          })}
          {error && <div className="error full" role="alert">{error}</div>}
          <div className="actions full"><button className="btn">Save</button><button type="button" className="btn secondary" onClick={() => setEditing(null)}>Cancel</button></div>
        </form>
      )}

      <Status state={{ ...list, data: list.data ? { items: list.data } : null }} emptyMsg="Nothing yet. Create the first one.">
        <div className="table-wrap"><table>
          <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}<th>Actions</th></tr></thead>
          <tbody>{(list.data || []).map((it) => (
            <tr key={it.id}>
              {columns.map((c) => <td key={c.key}>{c.render ? c.render(it) : it[c.key]}</td>)}
              <td><div className="actions"><button className="btn secondary small" onClick={() => startEdit(it)}>Edit</button><button className="btn danger small" onClick={() => remove(it)}>Delete</button></div></td>
            </tr>))}</tbody>
        </table></div>
      </Status>
    </>
  );
}

const statusBadge = (it) => <span className={`badge ${it.status === "published" ? "ok" : ["cancelled"].includes(it.status) ? "bad" : "warn"}`}>{it.status}</span>;

export const AdminArticles = () => (
  <Manager title="Articles" resource="articles" titleKey="title" catType="article"
    defaults={{ status: "draft", section: "culture", featured: false }}
    fields={[
      { key: "title", label: "Title", required: true }, { key: "slug", label: "Slug" },
      { key: "section", label: "Section", type: "select", options: ["heritage", "culture", "people", "food", "photo"] },
      { key: "status", label: "Status", type: "select", options: ["draft", "published", "archived"] },
      { key: "category_id", label: "Category", type: "category" }, { key: "cover_image", label: "Cover image", type: "image" },
      { key: "summary", label: "Summary", type: "textarea", full: true }, { key: "body", label: "Body (blank line = new paragraph)", type: "textarea", full: true },
      { key: "gallery", label: "Gallery", type: "gallery" }, { key: "featured", label: "Feature on homepage", type: "bool" },
    ]}
    columns={[{ key: "title", label: "Title" }, { key: "section", label: "Section" }, { key: "status", label: "Status", render: statusBadge }, { key: "published_at", label: "Published", render: (i) => fmtDate(i.published_at) || "-" }]} />
);

export const AdminPlaces = () => (
  <Manager title="Places" resource="places" titleKey="name" catType="place"
    defaults={{ status: "published", featured: false }}
    fields={[
      { key: "name", label: "Name", required: true }, { key: "slug", label: "Slug" },
      { key: "area", label: "Area / neighbourhood" }, { key: "address", label: "Address" },
      { key: "category_id", label: "Category", type: "category" }, { key: "status", label: "Status", type: "select", options: ["draft", "published", "archived"] },
      { key: "cover_image", label: "Cover image", type: "image" }, { key: "map_link", label: "Map link" },
      { key: "description", label: "Description", type: "textarea", full: true }, { key: "practical_notes", label: "Practical notes", type: "textarea", full: true },
      { key: "featured", label: "Feature on homepage", type: "bool" },
    ]}
    columns={[{ key: "name", label: "Name" }, { key: "area", label: "Area" }, { key: "category", label: "Category", render: (i) => i.category?.name || "-" }, { key: "status", label: "Status", render: statusBadge }]} />
);

export const AdminEvents = () => (
  <Manager title="Events" resource="events" titleKey="title" catType="event"
    defaults={{ status: "draft", entry_fee: "Free", featured: false, is_sample: false }}
    fields={[
      { key: "title", label: "Title", required: true }, { key: "slug", label: "Slug" },
      { key: "start_at", label: "Starts", type: "datetime", required: true }, { key: "end_at", label: "Ends", type: "datetime" },
      { key: "venue", label: "Venue" }, { key: "neighbourhood", label: "Neighbourhood" },
      { key: "entry_fee", label: "Entry fee (type Free for free)" }, { key: "organiser", label: "Organiser" },
      { key: "booking_url", label: "Booking URL" }, { key: "cover_image", label: "Cover image", type: "image" },
      { key: "status", label: "Status", type: "select", options: ["draft", "published", "postponed", "cancelled", "archived"] },
      { key: "category_id", label: "Category", type: "category" },
      { key: "description", label: "Description", type: "textarea", full: true },
      { key: "featured", label: "Feature on homepage", type: "bool" }, { key: "is_sample", label: "Sample / unverified data", type: "bool" },
    ]}
    columns={[{ key: "title", label: "Title" }, { key: "start_at", label: "Starts", render: (i) => fmtDateTime(i.start_at) }, { key: "status", label: "Status", render: statusBadge }, { key: "is_sample", label: "Sample", render: (i) => (i.is_sample ? "Yes" : "No") }]} />
);

export const AdminCategories = () => (
  <Manager title="Categories" resource="categories" titleKey="name" defaults={{ content_type: "article" }}
    fields={[
      { key: "name", label: "Name", required: true }, { key: "slug", label: "Slug" },
      { key: "content_type", label: "Used for", type: "select", options: ["article", "place", "event"] },
      { key: "description", label: "Description", full: true },
    ]}
    columns={[{ key: "name", label: "Name" }, { key: "slug", label: "Slug" }, { key: "content_type", label: "Type" }]} />
);

function ImageField({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const pick = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true); setErr("");
    try { onChange(await upload(file)); } catch (ex) { setErr(ex.message); } finally { setBusy(false); e.target.value = ""; }
  };
  return (
    <label>{label}
      <div className="row-end">
        {value && <img className="thumb" src={media(value)} alt="" />}
        <input type="text" value={value} onChange={(e) => onChange(e.target.value)} placeholder="Paste a URL or upload" style={{ flex: 1, minWidth: 140 }} />
        <input type="file" accept="image/jpeg,image/png,image/webp" onChange={pick} disabled={busy} aria-label={`Upload ${label}`} />
      </div>
      {busy && <span className="meta">Uploading…</span>}{err && <span className="meta" style={{ color: "#8a1c14" }}>{err}</span>}
    </label>
  );
}

function GalleryField({ value, onChange }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const update = (i, k, v) => onChange(value.map((g, j) => (j === i ? { ...g, [k]: v } : g)));
  const add = async (e) => {
    const files = [...(e.target.files || [])];
    setBusy(true); setErr("");
    try { const items = []; for (const f of files) items.push({ url: await upload(f), caption: "", alt: "", credit: "" }); onChange([...value, ...items]); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); e.target.value = ""; }
  };
  return (
    <div className="full">
      <b style={{ fontSize: ".82rem" }}>Photo gallery (for photo stories)</b>
      {value.map((g, i) => (
        <div key={i} className="gal-row" style={{ marginTop: 8 }}>
          <input value={g.caption} placeholder="Caption" onChange={(e) => update(i, "caption", e.target.value)} />
          <input value={g.alt} placeholder="Alt text (describe the image)" onChange={(e) => update(i, "alt", e.target.value)} />
          <input value={g.credit} placeholder="Photographer credit" onChange={(e) => update(i, "credit", e.target.value)} />
          <button type="button" className="btn secondary small" onClick={() => onChange(value.filter((_, j) => j !== i))}>Remove</button>
          <span className="meta" style={{ gridColumn: "1 / -1" }}>{g.url}</span>
        </div>
      ))}
      <input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={add} disabled={busy} aria-label="Add gallery images" />
      {busy && <span className="meta"> Uploading…</span>}{err && <div className="error">{err}</div>}
    </div>
  );
}

export function AdminSubmissions() {
  const [v, setV] = useState(0);
  const list = useFetch(() => api("/admin/submissions"), [v]);
  const review = async (s, status) => {
    const notes = window.prompt(status === "approved" ? "Optional note to the contributor (approval creates a DRAFT article):" : "Note to the contributor (required so they know why):", "");
    if (notes === null || (status !== "approved" && !notes.trim())) return;
    try { await api(`/admin/submissions/${s.id}/review`, { method: "POST", body: { status, reviewer_notes: notes } }); setV(v + 1); }
    catch (ex) { alert(ex.message); }
  };
  return (
    <>
      <h1 style={{ fontSize: "1.8rem" }}>Submissions</h1>
      <Status state={{ ...list, data: list.data ? { items: list.data } : null }} emptyMsg="No submissions yet.">
        <div className="table-wrap"><table>
          <thead><tr><th>Title</th><th>From</th><th>Kind</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>{(list.data || []).map((s) => (
            <tr key={s.id}>
              <td><b>{s.title}</b><br /><span className="meta">{s.body.slice(0, 140)}{s.body.length > 140 ? "…" : ""}</span>{s.media_links && <><br /><span className="meta">Links: {s.media_links}</span></>}</td>
              <td>{s.user?.name}<br /><span className="meta">{s.user?.email}</span></td><td>{s.kind}</td>
              <td><span className={`badge ${s.status === "approved" ? "ok" : s.status === "rejected" ? "bad" : "warn"}`}>{s.status.replace("_", " ")}</span></td>
              <td><div className="actions">
                <button className="btn small" onClick={() => review(s, "approved")}>Approve</button>
                <button className="btn secondary small" onClick={() => review(s, "changes_requested")}>Request edits</button>
                <button className="btn danger small" onClick={() => review(s, "rejected")}>Reject</button>
              </div></td>
            </tr>))}</tbody>
        </table></div>
      </Status>
    </>
  );
}

export function AdminInbox() {
  const [v, setV] = useState(0);
  const msgs = useFetch(() => api("/admin/messages"), [v]);
  const subs = useFetch(() => api("/admin/subscribers"), []);
  const handle = async (m) => { await api(`/admin/messages/${m.id}/handled`, { method: "POST" }); setV(v + 1); };
  const active = (subs.data || []).filter((x) => !x.unsubscribed_at);
  return (
    <>
      <h1 style={{ fontSize: "1.8rem" }}>Inbox</h1>
      <h2 style={{ fontSize: "1.2rem" }}>Contact messages</h2>
      <Status state={{ ...msgs, data: msgs.data ? { items: msgs.data } : null }} emptyMsg="No messages.">
        <div className="table-wrap"><table><thead><tr><th>From</th><th>Message</th><th>Received</th><th></th></tr></thead>
          <tbody>{(msgs.data || []).map((m) => <tr key={m.id}><td>{m.name}<br /><a href={`mailto:${m.email}`}>{m.email}</a></td><td style={{ whiteSpace: "pre-wrap" }}>{m.message}</td><td>{fmtDateTime(m.created_at)}</td><td>{m.handled ? <span className="badge ok">Handled</span> : <button className="btn small" onClick={() => handle(m)}>Mark handled</button>}</td></tr>)}</tbody></table></div>
      </Status>
      <h2 style={{ fontSize: "1.2rem", marginTop: 28 }}>Newsletter subscribers ({active.length} active)</h2>
      <Status state={{ ...subs, data: subs.data ? { items: subs.data } : null }} emptyMsg="No subscribers yet.">
        <div className="table-wrap"><table><thead><tr><th>Email</th><th>Joined</th><th>Status</th></tr></thead>
          <tbody>{(subs.data || []).map((x) => <tr key={x.id}><td>{x.email}</td><td>{fmtDate(x.created_at)}</td><td>{x.unsubscribed_at ? <span className="badge">Unsubscribed</span> : <span className="badge ok">Active</span>}</td></tr>)}</tbody></table></div>
      </Status>
    </>
  );
}

export function AdminUsers() {
  const { user: me } = useAuth();
  const [v, setV] = useState(0);
  const list = useFetch(() => api("/admin/users"), [v]);
  const patch = async (u, body) => { try { await api(`/admin/users/${u.id}`, { method: "PUT", body }); setV(v + 1); } catch (ex) { alert(ex.message); } };
  if (me.role !== "admin") return <div className="error">Only admins can manage users.</div>;
  return (
    <>
      <h1 style={{ fontSize: "1.8rem" }}>Users</h1>
      <Status state={{ ...list, data: list.data ? { items: list.data } : null }}>
        <div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr></thead>
          <tbody>{(list.data || []).map((u) => (
            <tr key={u.id}><td>{u.name}</td><td>{u.email}</td>
              <td><select value={u.role} disabled={u.id === me.id} onChange={(e) => patch(u, { role: e.target.value })}>{["reader", "contributor", "editor", "admin"].map((r) => <option key={r}>{r}</option>)}</select></td>
              <td><button className={`btn small ${u.is_active === false ? "danger" : "secondary"}`} disabled={u.id === me.id} onClick={() => patch(u, { is_active: !(u.is_active !== false) })}>{u.is_active === false ? "Reactivate" : "Deactivate"}</button></td></tr>))}</tbody></table></div>
      </Status>
    </>
  );
}
