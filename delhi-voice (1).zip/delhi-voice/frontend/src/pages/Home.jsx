import { Link } from "react-router-dom";
import { api, qs } from "../api";
import { Cover, Status, useFetch, usePageMeta, fmtDate, fmtDateTime } from "../components";

export const PlaceCard = ({ p }) => (
  <Link to={`/heritage/${p.slug}`} className="card">
    <Cover src={p.cover_image} label={p.name} />
    <div className="card-body">
      <span className="tag">{p.category?.name || "Place"}</span>
      <h3>{p.name}</h3>
      <p>{p.description.slice(0, 110)}{p.description.length > 110 ? "…" : ""}</p>
      <span className="meta">{p.area}</span>
    </div>
  </Link>
);

export const ArticleCard = ({ a }) => (
  <Link to={`/stories/${a.slug}`} className="card">
    <Cover src={a.cover_image} label={a.title} />
    <div className="card-body">
      <span className="tag">{a.category?.name || a.section}</span>
      <h3>{a.title}</h3>
      <p>{a.summary}</p>
      <span className="meta">{a.author?.name ? `By ${a.author.name} · ` : ""}{fmtDate(a.published_at)}</span>
    </div>
  </Link>
);

export const EventCard = ({ e }) => (
  <Link to={`/events/${e.slug}`} className="card">
    <Cover src={e.cover_image} label={e.title} seed={3} />
    <div className="card-body">
      <span className="tag">{e.category?.name || "Event"}</span>
      <h3>{e.title}</h3>
      <span className="meta">{fmtDateTime(e.start_at)} · {e.venue}</span>
      <div>
        <span className="badge">{e.entry_fee}</span>{" "}
        {e.status === "cancelled" && <span className="badge bad">Cancelled</span>}
        {e.status === "postponed" && <span className="badge warn">Postponed</span>}
        {e.is_sample && <span className="badge warn">Sample</span>}
      </div>
    </div>
  </Link>
);

function Section({ title, to, state, render }) {
  return (
    <section className="section container">
      <div className="section-head">
        <h2>{title}</h2>
        {to && <Link to={to}>View all →</Link>}
      </div>
      <Status state={state}>
        <div className="grid">{state.data?.items?.map(render)}</div>
      </Status>
    </section>
  );
}

export default function Home() {
  usePageMeta();
  const picks = useFetch(() => api(`/articles${qs({ featured: true, size: 3 })}`), []);
  const places = useFetch(() => api(`/places${qs({ featured: true, size: 3 })}`), []);
  const events = useFetch(() => api(`/events${qs({ size: 3 })}`), []);
  const latest = useFetch(() => api(`/articles${qs({ size: 3 })}`), []);
  return (
    <>
      <section className="hero">
        <div className="container">
          <span className="eyebrow">The City. The Culture. The Stories.</span>
          <h1>Discover the many voices of Delhi</h1>
          <p>Heritage, culture, events, food and the people who keep this city alive, told like a magazine and organised like a guide.</p>
          <Link className="btn" to="/heritage">Explore Delhi</Link>{" "}
          <Link className="btn secondary" style={{ color: "#fff", borderColor: "#fff" }} to="/events">What's on</Link>
        </div>
      </section>
      <Section title="Editor's picks" to="/stories" state={picks} render={(a) => <ArticleCard key={a.id} a={a} />} />
      <Section title="Explore heritage places" to="/heritage" state={places} render={(p) => <PlaceCard key={p.id} p={p} />} />
      <Section title="Upcoming events" to="/events" state={events} render={(e) => <EventCard key={e.id} e={e} />} />
      <Section title="Latest stories" to="/stories" state={latest} render={(a) => <ArticleCard key={a.id} a={a} />} />
    </>
  );
}
