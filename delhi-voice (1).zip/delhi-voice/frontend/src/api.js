// In dev, Vite proxies /api to FastAPI. In production set VITE_API_URL (e.g. https://your-api.onrender.com).
const BASE = import.meta.env.VITE_API_URL || "";

export const getToken = () => localStorage.getItem("dv_token");
export const setToken = (t) => (t ? localStorage.setItem("dv_token", t) : localStorage.removeItem("dv_token"));

export async function api(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) {
    payload = new URLSearchParams(form);
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  } else if (body !== undefined) {
    payload = JSON.stringify(body);
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(`${BASE}/api${path}`, { method, headers, body: payload });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    let msg = data.detail || "Something went wrong";
    if (Array.isArray(msg)) msg = msg.map((e) => `${e.loc?.slice(1).join(".")}: ${e.msg}`).join("; ");
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const qs = (obj) => {
  const p = new URLSearchParams();
  Object.entries(obj).forEach(([k, v]) => v !== "" && v != null && p.set(k, v));
  const s = p.toString();
  return s ? `?${s}` : "";
};

export const media = (u) => (u && u.startsWith("/uploads/") ? `${BASE}${u}` : u);

export async function upload(file) {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${BASE}/api/admin/upload`, { method: "POST", headers: { Authorization: `Bearer ${getToken()}` }, body: fd });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Upload failed");
  return data.url;
}
